﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Linq;
using System.Text;
using System.Drawing;
using MyRealSenseCSharp;

namespace sample3dseg.cs
{
    //enum StreamMode { LIVE, RECORD,PLAY};
   // enum ColorType { COLOR, DEPTH, SEGMENTED};
    class RenderStreams
    {
        public ColorType colorType = ColorType.SEGMENTED;
        public FPSTimer timer = null;
        public StreamMode streamMode = StreamMode.LIVE;
        private PXCMSession session;
        private volatile bool closing = false;
        public bool Stop = false;
        private volatile bool stop = false;
      
        public int primary = 0;
        public int secondary = 1;
        private string filename = null;
        private Dictionary<string, PXCMCapture.DeviceInfo> devices = new Dictionary<string, PXCMCapture.DeviceInfo>();
        private Dictionary<string, int> devices_iuid = new Dictionary<string, int>();
        private Dictionary<string, PXCMCapture.Device.StreamProfile> profiles = new Dictionary<string, PXCMCapture.Device.StreamProfile>();
        private Dictionary<string, PXCMCapture.Device.StreamProfile> dprofiles = new Dictionary<string, PXCMCapture.Device.StreamProfile>();
        private MainForm form;
        List<string> deviceList = new List<string>();
        string selectedDevice = "";
        string selectedProfile = "";
        string selectedDProfile = "";
        private void PopulateDeviceMenu()
        {
            devices.Clear();
            devices_iuid.Clear();

            PXCMSession.ImplDesc desc = new PXCMSession.ImplDesc();
            desc.group = PXCMSession.ImplGroup.IMPL_GROUP_SENSOR;
            desc.subgroup = PXCMSession.ImplSubgroup.IMPL_SUBGROUP_VIDEO_CAPTURE;

          
            for (int i = 0; ; i++)
            {
                PXCMSession.ImplDesc desc1;
                if (session.QueryImpl(desc, i, out desc1) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                PXCMCapture capture;
                if (session.CreateImpl<PXCMCapture>(desc1, out capture) < pxcmStatus.PXCM_STATUS_NO_ERROR) continue;
                for (int j = 0; ; j++)
                {
                    PXCMCapture.DeviceInfo dinfo;
                    if (capture.QueryDeviceInfo(j, out dinfo) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                    if (dinfo.model != PXCMCapture.DeviceModel.DEVICE_MODEL_IVCAM) continue;

                    string sm1 = dinfo.name;
                    if (sm1.ToLower().Contains("realsense"))
                        selectedDevice = sm1;
                    devices[sm1] = dinfo;
                    devices_iuid[sm1] = desc1.iuid;
                    deviceList.Add(sm1);
                }
                capture.Dispose();
            }
            

        //    PopulateColorMenus(DeviceMenu.DropDownItems[0] as ToolStripMenuItem);
          //  PopulateDepthMenus(DeviceMenu.DropDownItems[0] as ToolStripMenuItem);
        }
        private string ProfileToString(PXCMCapture.Device.StreamProfile pinfo)
        {
            string line = pinfo.imageInfo.format.ToString().Substring(13) + " " + pinfo.imageInfo.width + "x" + pinfo.imageInfo.height + " ";
            if (pinfo.frameRate.min != pinfo.frameRate.max)
            {
                line += (float)pinfo.frameRate.min + "-" +
                      (float)pinfo.frameRate.max;
            }
            else
            {
                float fps = (pinfo.frameRate.min != 0) ? pinfo.frameRate.min : pinfo.frameRate.max;
                line += fps;
            }
            return line;
        }
        private void PopulateColorMenus()
        {
            string device_item = selectedDevice;
            PXCMSession.ImplDesc desc = new PXCMSession.ImplDesc();
            desc.group = PXCMSession.ImplGroup.IMPL_GROUP_SENSOR;
            desc.subgroup = PXCMSession.ImplSubgroup.IMPL_SUBGROUP_VIDEO_CAPTURE;
            desc.iuid = devices_iuid[device_item];
            desc.cuids[0] = PXCMCapture.CUID;

            profiles.Clear();
          
            PXCMCapture capture;
            PXCMCapture.DeviceInfo dinfo2 = devices[selectedDevice];

            PXCMSenseManager pp = session.CreateSenseManager();
            if (pp == null) return;
            if (pp.Enable3DSeg() < pxcmStatus.PXCM_STATUS_NO_ERROR) return;
            PXCM3DSeg s = pp.Query3DSeg();
            if (s == null) return;
            PXCMVideoModule m = s.QueryInstance<PXCMVideoModule>();
            if (m == null) return;

            if (session.CreateImpl<PXCMCapture>(desc, out capture) >= pxcmStatus.PXCM_STATUS_NO_ERROR)
            {
                PXCMCapture.Device device = capture.CreateDevice(dinfo2.didx);
                if (device != null)
                {
                    PXCMCapture.Device.StreamProfileSet profile = new PXCMCapture.Device.StreamProfileSet(); ;
                    if (((int)dinfo2.streams & (int)PXCMCapture.StreamType.STREAM_TYPE_COLOR) != 0)
                    {
                        for (int p = 0; ; p++)
                        {
                            if (device.QueryStreamProfileSet(PXCMCapture.StreamType.STREAM_TYPE_COLOR, p, out profile) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                            PXCMCapture.Device.StreamProfile sprofile = profile[PXCMCapture.StreamType.STREAM_TYPE_COLOR];

                            // Only populate profiles which are supported by the module
                            bool bFound = false;
                            int i = 0;
                            PXCMVideoModule.DataDesc inputs;
                            while (!bFound
                                && (m.QueryCaptureProfile(i++, out inputs) >= pxcmStatus.PXCM_STATUS_NO_ERROR))
                            {
                                if ((sprofile.imageInfo.height == inputs.streams.color.sizeMax.height)
                                    && (sprofile.imageInfo.width == inputs.streams.color.sizeMax.width)
                                    && (sprofile.frameRate.max == inputs.streams.color.frameRate.max))
                                {
                                    bFound = true;
                                }
                            }
                            if (bFound)
                            {
                                string sm1 = ProfileToString(sprofile);
                                profiles[sm1] = sprofile; if (selectedProfile.Length < 2)
                                {
                                    selectedProfile = sm1;
                                }
                                
                            }
                        }
                    }
                    device.Dispose();
                }
                capture.Dispose();
            }
            m.Dispose();
            pp.Dispose();
         
        }

        private void PopulateDepthMenus()
        {
            string device_item = selectedDevice;
            PXCMSession.ImplDesc desc = new PXCMSession.ImplDesc();
            desc.group = PXCMSession.ImplGroup.IMPL_GROUP_SENSOR;
            desc.subgroup = PXCMSession.ImplSubgroup.IMPL_SUBGROUP_VIDEO_CAPTURE;
            desc.iuid = devices_iuid[device_item];
            desc.cuids[0] = PXCMCapture.CUID;

        
            PXCMCapture capture;
            PXCMCapture.DeviceInfo dinfo2 = devices[selectedDevice];

            PXCMSenseManager pp = session.CreateSenseManager();
            if (pp == null) return;
            if (pp.Enable3DSeg() < pxcmStatus.PXCM_STATUS_NO_ERROR) return;
            PXCM3DSeg s = pp.Query3DSeg();
            if (s == null) return;
            PXCMVideoModule m = s.QueryInstance<PXCMVideoModule>();
            if (m == null) return;

            if (session.CreateImpl<PXCMCapture>(desc, out capture) >= pxcmStatus.PXCM_STATUS_NO_ERROR)
            {
                PXCMCapture.Device device = capture.CreateDevice(dinfo2.didx);
                if (device != null)
                {
                    PXCMCapture.Device.StreamProfileSet profile = new PXCMCapture.Device.StreamProfileSet(); ;
                    PXCMCapture.Device.StreamProfile color_profile = profiles[selectedProfile];
                    if (((int)dinfo2.streams & (int)PXCMCapture.StreamType.STREAM_TYPE_DEPTH) != 0)
                    {
                        for (int p = 0; ; p++)
                        {
                            if (device.QueryStreamProfileSet(PXCMCapture.StreamType.STREAM_TYPE_DEPTH, p, out profile) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                            PXCMCapture.Device.StreamProfile sprofile = profile[PXCMCapture.StreamType.STREAM_TYPE_DEPTH];

                            bool bFound = false;
                            int i = 0;
                            PXCMVideoModule.DataDesc inputs;
                            while (!bFound
                                && (m.QueryCaptureProfile(i++, out inputs) >= pxcmStatus.PXCM_STATUS_NO_ERROR))
                            {
                                if ((sprofile.imageInfo.height == inputs.streams.depth.sizeMax.height)
                                    && (sprofile.imageInfo.width == inputs.streams.depth.sizeMax.width)
                                    && (sprofile.frameRate.max == inputs.streams.depth.frameRate.max)
                                    && (color_profile.frameRate.max == inputs.streams.depth.frameRate.max))
                                {
                                    bFound = true;
                                }
                            }
                            if (bFound)
                            {
                               string sm1 = ProfileToString(sprofile);
                                dprofiles[sm1] = sprofile;
                                if (selectedDProfile.Length < 2)
                                {
                                    selectedDProfile = sm1;
                                }
                               
                            }
                        }
                    }
                    device.Dispose();
                }
                capture.Dispose();
            }
            m.Dispose();
            pp.Dispose();

           
        }
        public Bitmap[] bitmaps = new Bitmap[2];
        public RenderStreams(MainForm mf,PXCMSession session, StreamMode mode, ColorType cType)
        {
            form = mf;
            this.session = session;
            PopulateDeviceMenu();
            PopulateColorMenus();
            PopulateDepthMenus();
            streamMode = mode;
            colorType = cType;
            Stop = false;
        }

        public static void LightenBackground(PXCMImage segmented_image)
        {
            PXCMImage.ImageData segmented_image_data;
            segmented_image.AcquireAccess(
                PXCMImage.Access.ACCESS_READ_WRITE, 
                PXCMImage.PixelFormat.PIXEL_FORMAT_RGB32, 
                out segmented_image_data);

            int height = segmented_image.QueryInfo().height;
            int width = segmented_image.QueryInfo().width;

            for (int y = 0; y < height; y++)
            {
                unsafe
                {
                    byte* p = (byte*)segmented_image_data.planes[0] + y * segmented_image_data.pitches[0];
                    const byte GREY = 0x7f;
                    for (int x = 0; x < width; x++)
                    {
                        if (p[3] > 0)
                        {
                            // When the user moves into the near/far extent, the alpha values will drop from 255 to 1.
                            // This can be used to fade the user in/out as a cue to move into the ideal operating range.
                            float blend_factor = (float)p[3] / (float)255;
                            for (int ch = 0; ch < 3; ch++)
                            {
                                byte not_visible = (byte)((p[ch] >> 4) + GREY);
                                p[ch] = (byte)(p[ch] * blend_factor + not_visible * (1.0f - blend_factor));
                            }
                        }
                        else for (int ch = 0; ch < 3; ch++) p[ch] = (byte)((p[ch] >> 4) + GREY);

                        p += 4;
                    }
                }
            }

            segmented_image.ReleaseAccess(segmented_image_data);
        }

        public static byte[] GetRGB32Pixels(PXCMImage image, out int cwidth, out int cheight)
        {
            PXCMImage.ImageData cdata;
            byte[] cpixels=null;
            cwidth = cheight = 0;
            if (image.AcquireAccess(PXCMImage.Access.ACCESS_READ, PXCMImage.PixelFormat.PIXEL_FORMAT_RGB32, out cdata)>=pxcmStatus.PXCM_STATUS_NO_ERROR) 
            {
                cwidth = (int)cdata.pitches[0] / sizeof(Int32);
                cheight = (int)image.info.height;
                cpixels = cdata.ToByteArray(0, (int)cdata.pitches[0] * cheight);
                image.ReleaseAccess(cdata);
            }
            return cpixels;
        }
        string statText = "";
        void UpdateStatus(string s)
        {
            statText = s;
        }
        public void SetBitmap(int index, int width, int height, byte[] pixels)
        {
            if (pixels == null) return;
            lock (this)
            {
                if (bitmaps[index] != null) bitmaps[index].Dispose();
                bitmaps[index] = new Bitmap(width, height, System.Drawing.Imaging.PixelFormat.Format32bppRgb);
                System.Drawing.Imaging.BitmapData data = bitmaps[index].LockBits(new Rectangle(0, 0, width, height), System.Drawing.Imaging.ImageLockMode.WriteOnly, System.Drawing.Imaging.PixelFormat.Format32bppRgb);
                Marshal.Copy(pixels, 0, data.Scan0, width * height * 4);
                bitmaps[index].UnlockBits(data);
            }
        }
        PXCMSenseManager pp;
        PXCMCapture.DeviceInfo dinfo2;
        PXCMCapture.Device.StreamProfileSet filter;
        PXCMCapture.Device.StreamProfile cinfo;
        PXCMCapture.Device.StreamProfile dinfo;
        pxcmStatus result;
        PXCMCapture.Device d;
        pxcmStatus s;
        ushort DepthConfidenceThreshold;
        int IVCAMLaserPower;
        PXCMCapture.Device.IVCAMAccuracy IVCAMAccuracy;
        int IVCAMMotionRangeTradeOff;
        int IVCAMFilterOption;
        PXCMCapture.Device.MirrorMode MirrorMode;
        PXCMCapture.Sample sample;
        bool sts;
        Projection projection;
        public bool OneTimeInitializationBeforeLooping()
        {
            sts = true;

            /* Create an instance of the PXCSenseManager interface */
            pp = PXCMSenseManager.CreateInstance();
            if (pp == null)
            {
                UpdateStatus("Failed to create an SDK pipeline object");
                return false;
            }
            if (!streamMode.Equals(StreamMode.LIVE))
                pp.captureManager.SetFileName("1.rssdk", streamMode.Equals(StreamMode.RECORD));

            /* Set Input Source */
            dinfo2 = devices[selectedDevice];
            if (streamMode.Equals(StreamMode.LIVE) || streamMode.Equals(StreamMode.PLAY))
                pp.captureManager.FilterByDeviceInfo(dinfo2);

            /* Set Color & Depth Resolution */
            filter = new PXCMCapture.Device.StreamProfileSet();
            cinfo = profiles[selectedProfile];
            if (cinfo.imageInfo.format != 0)
            {
                Single cfps = cinfo.frameRate.max;
                pp.EnableStream(PXCMCapture.StreamType.STREAM_TYPE_COLOR, cinfo.imageInfo.width, cinfo.imageInfo.height, cfps);
                filter.color = cinfo;
            }

            dinfo = dprofiles[selectedDProfile];
            if (dinfo.imageInfo.format != 0)
            {
                Single dfps = dinfo.frameRate.max;
                pp.EnableStream(PXCMCapture.StreamType.STREAM_TYPE_DEPTH, dinfo.imageInfo.width, dinfo.imageInfo.height, dfps);
                filter.depth = dinfo;
            }
            pp.captureManager.FilterByStreamProfiles(filter);


            UpdateStatus("Init Started");

            // Enable the User Segmentation video module
            pxcmStatus result = pp.Enable3DSeg();
            if (pp.Init() >= pxcmStatus.PXCM_STATUS_NO_ERROR)
            {
                /* PXC3DSeg Video Module is tuned to work best with a particular set of device settings. */
                /* So, first we save a copy of the existing values (to restore before exit)... */
                d = pp.captureManager.device;

                DepthConfidenceThreshold = d.QueryDepthConfidenceThreshold();
                IVCAMLaserPower = d.QueryIVCAMLaserPower();
                IVCAMAccuracy = d.QueryIVCAMAccuracy();
                IVCAMMotionRangeTradeOff = d.QueryIVCAMMotionRangeTradeOff();
                IVCAMFilterOption = d.QueryIVCAMFilterOption();
                MirrorMode = d.QueryMirrorMode();

                /* ...then, change the values to the set known to work best with segmentation */
                s = d.SetDepthConfidenceThreshold(0);
                s = d.SetIVCAMLaserPower(16);
                s = d.SetIVCAMAccuracy(PXCMCapture.Device.IVCAMAccuracy.IVCAM_ACCURACY_COARSE);
                s = d.SetIVCAMMotionRangeTradeOff(21);
                s = d.SetIVCAMFilterOption(6);
                s = d.SetMirrorMode(PXCMCapture.Device.MirrorMode.MIRROR_MODE_HORIZONTAL);

                /* For UV Mapping & Projection only: Save certain properties */
                projection = new Projection(pp.session, pp.captureManager.device, dinfo.imageInfo);
                return true;
            }
            else
            {
                sts = false;
                return false;
            }
        }
        public void Finish()
        {
            projection.Dispose();

            // Restore the device setting that were changed
            s = d.SetDepthConfidenceThreshold(DepthConfidenceThreshold);
            s = d.SetIVCAMLaserPower(IVCAMLaserPower);
            s = d.SetIVCAMAccuracy(IVCAMAccuracy);
            s = d.SetIVCAMMotionRangeTradeOff(IVCAMMotionRangeTradeOff);
            s = d.SetIVCAMFilterOption(IVCAMFilterOption);
            s = d.SetMirrorMode(MirrorMode);

            pp.Close();
            pp.Dispose();
            if (sts) UpdateStatus("Stopped");
        }
        public bool StreamColorDepth(bool synced) /* Stream Color and Depth Synchronously or Asynchronously */
        {

           

              UpdateStatus("Streaming");
                
                    /* Wait until a frame is ready: Synchronized or Asynchronous */
                    if (pp.AcquireFrame(synced) < pxcmStatus.PXCM_STATUS_NO_ERROR)
                    {
                        projection.Dispose();
                        return false;
                    }

                    /* Get Segmentation image from the User Segmentation video module */
                    PXCM3DSeg seg = pp.Query3DSeg();
                    if (seg == null)
                    {
                        pp.ReleaseFrame();
                        projection.Dispose();
                        pp.Close();
                        pp.Dispose();
                        UpdateStatus("Error: 3DSeg is not available");
                        return false;
                    }
                    PXCMImage segmented_image = seg.AcquireSegmentedImage();
                    if (segmented_image == null)
                    {
                        pp.ReleaseFrame();
                        projection.Dispose(); 
                        pp.Close();
                        pp.Dispose();
                        UpdateStatus("Error: 3DSeg did not return an image");
                        return false;
                    }

                    /* Lighen the background color channels according to the alpha channel (mask) */
                    LightenBackground(segmented_image);

                    /* Display images */
                    PXCMCapture.Sample sample = pp.QuerySample(); 
                    if (sample == null)
                    {
                        projection.Dispose();
                        return false;
                    }

                    int    bitmap_width, bitmap_height;
                    byte[] bitmap_data;
                    switch (colorType)
                    {
                        case ColorType.COLOR: // color
                            if (sample.color != null)
                            {
                                bitmap_data = GetRGB32Pixels(sample.color, out bitmap_width, out bitmap_height);
                                SetBitmap(0, bitmap_width, bitmap_height, bitmap_data);
                                timer.Tick(sample.color.info.format.ToString().Substring(13) + " " + sample.color.info.width + "x" + sample.color.info.height);
                            }
                            break;
                        case ColorType.DEPTH: // depth
                            if (sample.depth != null)
                            {
                                bitmap_data = GetRGB32Pixels(sample.depth, out bitmap_width, out bitmap_height);
                               SetBitmap(0, bitmap_width, bitmap_height, bitmap_data);
                                timer.Tick(sample.depth.info.format.ToString().Substring(13) + " " + sample.depth.info.width + "x" + sample.depth.info.height);
                            }
                            break;
                        case ColorType.SEGMENTED: // segmented
                            if (segmented_image != null)
                            {
                                bitmap_data = GetRGB32Pixels(segmented_image, out bitmap_width, out bitmap_height);
                                SetBitmap(0, bitmap_width, bitmap_height, bitmap_data);
                                timer.Tick("RGB32 " + sample.color.info.width + "x" + sample.color.info.height);
                            }
                            break;
                        }
                    /*
                    switch (form.secondary)
                        {
                        case 0: // color
                            if (sample.color != null) 
                            {
                                bitmap_data = GetRGB32Pixels(sample.color, out bitmap_width, out bitmap_height);
                               SetBitmap(1, bitmap_width, bitmap_height, bitmap_data);
                            }
                            break;
                        case 1: // depth
                            if (sample.depth != null)
                            {
                                bitmap_data = GetRGB32Pixels(sample.depth, out bitmap_width, out bitmap_height);
                                SetBitmap(1, bitmap_width, bitmap_height, bitmap_data);
                            }
                            break;
                        case 2: // segmented
                            if (segmented_image != null)
                            {
                                bitmap_data = GetRGB32Pixels(segmented_image, out bitmap_width, out bitmap_height);
                               SetBitmap(1, bitmap_width, bitmap_height, bitmap_data);
                            }
                            break;
                    }
                     * */
                    segmented_image.Dispose();
                   // form.UpdatePanel();
                    pp.ReleaseFrame();

                    return true;
           
           
        }
    }
}
