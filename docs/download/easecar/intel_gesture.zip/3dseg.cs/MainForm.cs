﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MyRealSenseCSharp;
using System.Net;

namespace sample3dseg.cs
{
    public partial class MainForm : Form
    {
        private PXCMSession session;
        private volatile bool closing = false;
        private volatile bool stop = false;
        private Bitmap[] bitmaps = new Bitmap[2];
        public int primary = 0;
        public int secondary = 1;
        private string filename = null;
        private Dictionary<ToolStripMenuItem, PXCMCapture.DeviceInfo> devices=new Dictionary<ToolStripMenuItem,PXCMCapture.DeviceInfo>();
        private Dictionary<ToolStripMenuItem, int> devices_iuid=new Dictionary<ToolStripMenuItem,int>();
        private Dictionary<ToolStripMenuItem, PXCMCapture.Device.StreamProfile> profiles=new Dictionary<ToolStripMenuItem,PXCMCapture.Device.StreamProfile>();

        public MainForm(PXCMSession session)
        {
            InitializeComponent();

            this.session = session;
            PopulateDeviceMenu();
            FormClosing += new FormClosingEventHandler(MainForm_FormClosing);
            MainPanel.Paint += new PaintEventHandler(Panel_Paint);
            PIPPanel.Paint += new PaintEventHandler(Panel_Paint);
        }

        private void PopulateDeviceMenu()
        {
            devices.Clear();
            devices_iuid.Clear();

            PXCMSession.ImplDesc desc = new PXCMSession.ImplDesc();
            desc.group = PXCMSession.ImplGroup.IMPL_GROUP_SENSOR;
            desc.subgroup = PXCMSession.ImplSubgroup.IMPL_SUBGROUP_VIDEO_CAPTURE;

            DeviceMenu.DropDownItems.Clear();

            for (int i = 0; ; i++)
            {
                PXCMSession.ImplDesc desc1;
                if (session.QueryImpl(desc, i, out desc1) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                PXCMCapture capture;
                if (session.CreateImpl<PXCMCapture>(desc1, out capture) < pxcmStatus.PXCM_STATUS_NO_ERROR) continue;
                for (int j = 0; ; j++)
                {
                    PXCMCapture.DeviceInfo dinfo;
                    if (capture.QueryDeviceInfo(j, out dinfo) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                    if (dinfo.model != PXCMCapture.DeviceModel.DEVICE_MODEL_IVCAM) continue;

                    ToolStripMenuItem sm1 = new ToolStripMenuItem(dinfo.name, null, new EventHandler(Device_Item_Click));
                    devices[sm1] = dinfo;
                    devices_iuid[sm1] = desc1.iuid;
                    DeviceMenu.DropDownItems.Add(sm1);
                }
                capture.Dispose();
            }
            if (DeviceMenu.DropDownItems.Count > 0)
                (DeviceMenu.DropDownItems[0] as ToolStripMenuItem).Checked = true;

            PopulateColorMenus(DeviceMenu.DropDownItems[0] as ToolStripMenuItem);
            PopulateDepthMenus(DeviceMenu.DropDownItems[0] as ToolStripMenuItem);
        }

        private bool PopulateDeviceFromFileMenu()
        {
            devices.Clear();
            devices_iuid.Clear();

            PXCMSession.ImplDesc desc = new PXCMSession.ImplDesc();
            desc.group = PXCMSession.ImplGroup.IMPL_GROUP_SENSOR;
            desc.subgroup = PXCMSession.ImplSubgroup.IMPL_SUBGROUP_VIDEO_CAPTURE;

            PXCMSession.ImplDesc desc1;
            PXCMCapture.DeviceInfo dinfo;
            PXCMSenseManager pp = PXCMSenseManager.CreateInstance();
            if (pp == null)
            {
                UpdateStatus("Init Failed");
                return false;
            }
            try
            {
                if (session.QueryImpl(desc, 0, out desc1) < pxcmStatus.PXCM_STATUS_NO_ERROR) throw null;
                if (pp.captureManager.SetFileName(filename, false) < pxcmStatus.PXCM_STATUS_NO_ERROR) throw null;
                if (pp.captureManager.LocateStreams() < pxcmStatus.PXCM_STATUS_NO_ERROR) throw null;
                pp.captureManager.QueryDevice().QueryDeviceInfo(out dinfo); 
            }
            catch
            {
                pp.Dispose();
                UpdateStatus("Init Failed");
                return false;
            }
            DeviceMenu.DropDownItems.Clear();
            ToolStripMenuItem sm1 = new ToolStripMenuItem(dinfo.name, null, new EventHandler(Device_Item_Click));
            devices[sm1] = dinfo;
            devices_iuid[sm1] = desc1.iuid;
            DeviceMenu.DropDownItems.Add(sm1);

            sm1 = new ToolStripMenuItem("playback from the file : ", null);
            sm1.Enabled = false;
            DeviceMenu.DropDownItems.Add(sm1);
            sm1 = new ToolStripMenuItem(filename, null);
            sm1.Enabled = false;
            DeviceMenu.DropDownItems.Add(sm1);
            if (DeviceMenu.DropDownItems.Count > 0)
                (DeviceMenu.DropDownItems[0] as ToolStripMenuItem).Checked = true;

            // populate color depth menu from the file
            profiles.Clear();
            ColorMenu.DropDownItems.Clear();
            DepthMenu.DropDownItems.Clear();
            PXCMCapture.Device device = pp.captureManager.QueryDevice(); 
            
            PXCMCapture.Device.StreamProfileSet profile = new PXCMCapture.Device.StreamProfileSet(); 
            if (((int)dinfo.streams & (int)PXCMCapture.StreamType.STREAM_TYPE_COLOR) != 0)
            {
                for (int p = 0; ; p++)
                {
                    if (device.QueryStreamProfileSet(PXCMCapture.StreamType.STREAM_TYPE_COLOR, p, out profile) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                    PXCMCapture.Device.StreamProfile sprofile = profile[PXCMCapture.StreamType.STREAM_TYPE_COLOR];
                    sm1 = new ToolStripMenuItem(ProfileToString(sprofile), null, new EventHandler(Color_Item_Click));
                    profiles[sm1] = sprofile;  
                    ColorMenu.DropDownItems.Add(sm1);
                }
            }

            if (((int)dinfo.streams & (int)PXCMCapture.StreamType.STREAM_TYPE_DEPTH) != 0)
            {
                for (int p = 0; ; p++)
                {
                    if (device.QueryStreamProfileSet(PXCMCapture.StreamType.STREAM_TYPE_DEPTH, p, out profile) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                    PXCMCapture.Device.StreamProfile sprofile = profile[PXCMCapture.StreamType.STREAM_TYPE_DEPTH];
                    sm1 = new ToolStripMenuItem(ProfileToString(sprofile), null, new EventHandler(Depth_Item_Click));
                    profiles[sm1] = sprofile;
                    DepthMenu.DropDownItems.Add(sm1);
                }
            }
          
            (ColorMenu.DropDownItems[0] as ToolStripMenuItem).Checked = true;
            (DepthMenu.DropDownItems[0] as ToolStripMenuItem).Checked = true;

            CheckSelection();
            pp.Close();
            pp.Dispose();

            StatusLabel.Text = "Ok";
            return true;
        }

        private void PopulateColorMenus(ToolStripMenuItem device_item)
        {
            PXCMSession.ImplDesc desc = new PXCMSession.ImplDesc();
            desc.group = PXCMSession.ImplGroup.IMPL_GROUP_SENSOR;
            desc.subgroup = PXCMSession.ImplSubgroup.IMPL_SUBGROUP_VIDEO_CAPTURE;
            desc.iuid = devices_iuid[device_item];
            desc.cuids[0] = PXCMCapture.CUID;

            profiles.Clear();
            ColorMenu.DropDownItems.Clear();
            PXCMCapture capture;
            PXCMCapture.DeviceInfo dinfo2 = GetCheckedDevice();

            PXCMSenseManager pp = session.CreateSenseManager();
            if (pp == null) return;
            if (pp.Enable3DSeg() < pxcmStatus.PXCM_STATUS_NO_ERROR) return;
            PXCM3DSeg s = pp.Query3DSeg();
            if (s == null) return;
            PXCMVideoModule m = s.QueryInstance<PXCMVideoModule>();
            if (m == null) return;

            if (session.CreateImpl<PXCMCapture>(desc, out capture) >= pxcmStatus.PXCM_STATUS_NO_ERROR) {
                PXCMCapture.Device device=capture.CreateDevice(dinfo2.didx);
                if (device!=null) {
                    PXCMCapture.Device.StreamProfileSet profile = new PXCMCapture.Device.StreamProfileSet(); ;
                    if (((int)dinfo2.streams & (int)PXCMCapture.StreamType.STREAM_TYPE_COLOR) != 0)
                    {
                        for (int p = 0; ; p++)
                        {
                            if (device.QueryStreamProfileSet(PXCMCapture.StreamType.STREAM_TYPE_COLOR, p, out profile) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                            PXCMCapture.Device.StreamProfile sprofile = profile[PXCMCapture.StreamType.STREAM_TYPE_COLOR];

                            // Only populate profiles which are supported by the module
                            bool bFound = false;
                            int i = 0;
                            PXCMVideoModule.DataDesc inputs;
                            while (!bFound
                                && (m.QueryCaptureProfile(i++, out inputs) >= pxcmStatus.PXCM_STATUS_NO_ERROR))
                            {
                                if ((sprofile.imageInfo.height == inputs.streams.color.sizeMax.height)
                                    && (sprofile.imageInfo.width == inputs.streams.color.sizeMax.width)
                                    && (sprofile.frameRate.max == inputs.streams.color.frameRate.max))
                                {
                                    bFound = true;
                                }
                            }
                            if (bFound)
                            {
                                ToolStripMenuItem sm1 = new ToolStripMenuItem(ProfileToString(sprofile), null, new EventHandler(Color_Item_Click));
                                profiles[sm1] = sprofile;
                                ColorMenu.DropDownItems.Add(sm1);
                            }
                        }
                    }
                    device.Dispose();
                }
                capture.Dispose();
            }
            m.Dispose();
            pp.Dispose();
            if (ColorMenu.DropDownItems.Count>0)
                (ColorMenu.DropDownItems[0] as ToolStripMenuItem).Checked = true;
        }


        private void PopulateDepthMenus(ToolStripMenuItem device_item)
        {
            PXCMSession.ImplDesc desc = new PXCMSession.ImplDesc();
            desc.group = PXCMSession.ImplGroup.IMPL_GROUP_SENSOR;
            desc.subgroup = PXCMSession.ImplSubgroup.IMPL_SUBGROUP_VIDEO_CAPTURE;
            desc.iuid = devices_iuid[device_item];
            desc.cuids[0] = PXCMCapture.CUID;

            DepthMenu.DropDownItems.Clear();
            PXCMCapture capture;
            PXCMCapture.DeviceInfo dinfo2 = GetCheckedDevice();

            PXCMSenseManager pp = session.CreateSenseManager();
            if (pp == null) return;
            if (pp.Enable3DSeg() < pxcmStatus.PXCM_STATUS_NO_ERROR) return;
            PXCM3DSeg s = pp.Query3DSeg();
            if (s == null) return;
            PXCMVideoModule m = s.QueryInstance<PXCMVideoModule>();
            if (m == null) return;

            if (session.CreateImpl<PXCMCapture>(desc, out capture) >= pxcmStatus.PXCM_STATUS_NO_ERROR) {
                PXCMCapture.Device device=capture.CreateDevice(dinfo2.didx);
                if (device!=null) 
                {
                    PXCMCapture.Device.StreamProfileSet profile = new PXCMCapture.Device.StreamProfileSet(); ;
                    PXCMCapture.Device.StreamProfile color_profile = GetColorConfiguration();
                    if (((int)dinfo2.streams & (int)PXCMCapture.StreamType.STREAM_TYPE_DEPTH) != 0)
                    {
                        for (int p = 0; ; p++)
                        {
                            if (device.QueryStreamProfileSet(PXCMCapture.StreamType.STREAM_TYPE_DEPTH, p, out profile) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                            PXCMCapture.Device.StreamProfile sprofile = profile[PXCMCapture.StreamType.STREAM_TYPE_DEPTH];

                            bool bFound = false;
                            int i = 0;
                            PXCMVideoModule.DataDesc inputs;
                            while (!bFound
                                && (m.QueryCaptureProfile(i++, out inputs) >= pxcmStatus.PXCM_STATUS_NO_ERROR))
                            {
                                if ((sprofile.imageInfo.height == inputs.streams.depth.sizeMax.height)
                                    && (sprofile.imageInfo.width == inputs.streams.depth.sizeMax.width)
                                    && (sprofile.frameRate.max == inputs.streams.depth.frameRate.max)
                                    && (color_profile.frameRate.max == inputs.streams.depth.frameRate.max))
                                {
                                    bFound = true;
                                }
                            }
                            if (bFound)
                            {
                                ToolStripMenuItem sm1 = new ToolStripMenuItem(ProfileToString(sprofile), null, new EventHandler(Depth_Item_Click));
                                profiles[sm1] = sprofile;
                                DepthMenu.DropDownItems.Add(sm1);
                            }
                        }
                    }
                    device.Dispose();
                }
                capture.Dispose();
            }
            m.Dispose();
            pp.Dispose();

            if (DepthMenu.DropDownItems.Count>0)
                (DepthMenu.DropDownItems[0] as ToolStripMenuItem).Checked = true;

            CheckSelection();
        }

        private string ProfileToString(PXCMCapture.Device.StreamProfile pinfo)
        {
            string line = pinfo.imageInfo.format.ToString().Substring(13)+" "+pinfo.imageInfo.width+"x"+pinfo.imageInfo.height+" ";
            if (pinfo.frameRate.min != pinfo.frameRate.max) {
                line += (float)pinfo.frameRate.min + "-" +
                      (float)pinfo.frameRate.max;
            } else {
                float fps = (pinfo.frameRate.min!=0)?pinfo.frameRate.min:pinfo.frameRate.max;
                line += fps;
            }
            return line;
        }

        private void Device_Item_Click(object sender, EventArgs e)
        {
            foreach (ToolStripMenuItem e1 in DeviceMenu.DropDownItems)
                e1.Checked = (sender == e1);
            PopulateColorMenus(sender as ToolStripMenuItem);
            PopulateDepthMenus(sender as ToolStripMenuItem);
            CheckSelection();
        }

        private void Color_Item_Click(object sender, EventArgs e)
        {
            foreach (ToolStripMenuItem e1 in ColorMenu.DropDownItems)
                e1.Checked = (sender == e1);
            foreach (ToolStripMenuItem e2 in DeviceMenu.DropDownItems)
                if (e2.Checked) PopulateDepthMenus(e2 as ToolStripMenuItem);
            CheckSelection();
        }

        private void Depth_Item_Click(object sender, EventArgs e)
        {
            foreach (ToolStripMenuItem e1 in DepthMenu.DropDownItems)
                e1.Checked = (sender == e1);
            CheckSelection();
        }

        private void Start_Click(object sender, EventArgs e)
        {
            Start.Enabled = false;
            Stop.Enabled = true;
            stop = false;
            System.Threading.Thread thread = new System.Threading.Thread(DoRendering);
            thread.Start();
            System.Threading.Thread.Sleep(5);
        }

        delegate bool DoRenderingBegin();
        delegate void DoRenderingEnd();
        TheUltimateRealSenseClass rs = null;
        
        private void DoRendering()
        {
           rs= new TheUltimateRealSenseClass(this,session,StreamMode.LIVE,ColorType.SEGMENTED);
           rs.timer = new FPSTimer(this);
           rs.OneTimeInitializationBeforeLooping();
           rs.Speak("Welcome to Smart I o T RC Car Demo", 80, 100, 80);
           int choice = 0;//0->segmented 1->hand
           while (!rs.Stop)
           {

               bool success = rs.StreamColorDepth(true);
               if (success)
               {
                   lock (this)
                   {
                       if (choice == 0)
                       {
                         //  bitmaps[index] = rs.bitmaps[index]; // for segmented image
                          bitmaps[index] = rs.DisplayJoints(rs.nodes, rs.numOfHands, rs.bitmaps[index], true, true, true);
                       }
                       if (choice == 1)
                       {
                           if (rs.labeledBitmap != null)
                           {
                               //bitmaps[index] = rs.DisplayJoints(rs.nodes, rs.numOfHands, rs.labeledBitmap, true, true, true);
                               bitmaps[index] = rs.labeledBitmap;
                           }
                       }
                       if(rs.emotionData!=null)
                       bitmaps[index] = rs.DisplayEmotionSentimentFaceLocation(rs.emotionData,bitmaps[index]);
                   }
                   MainPanel.Invalidate();
                   UpdatePanel();
               }

              
           }
           this.Invoke(new DoRenderingEnd(
                 delegate
                 {
                     rs.Finish();
                     Start.Enabled = true;
                     Stop.Enabled = false;
                     MainMenu.Enabled = true;
                     if (closing) Close();
                 }
             ));
        }

        public PXCMCapture.DeviceInfo GetCheckedDevice()
        {
            foreach (ToolStripMenuItem e in DeviceMenu.DropDownItems)
            {
                if (devices.ContainsKey(e))
                {
                    if (e.Checked) return devices[e];
                }
            }
            return new PXCMCapture.DeviceInfo();
        }

        public bool GetColorState()
        {
            return Color.Checked;
        }

        public bool GetDepthState()
        {
            return Depth.Checked;
        }

        public bool GetSegmentedState()
        {
            return Segmented.Checked;
        }

        private PXCMCapture.Device.StreamProfile GetConfiguration(ToolStripMenuItem m)
        {
            foreach (ToolStripMenuItem e in m.DropDownItems)
                if (e.Checked) return profiles[e];
            return new PXCMCapture.Device.StreamProfile();
        }

        public PXCMCapture.Device.StreamProfile GetColorConfiguration()
        {
            return GetConfiguration(ColorMenu);
        }

        public PXCMCapture.Device.StreamProfile GetDepthConfiguration()
        {
            return GetConfiguration(DepthMenu);
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            stop = true;
            e.Cancel = Stop.Enabled;
            closing = true;
        }

        private delegate void UpdateStatusDelegate(string status);
        public void UpdateStatus(string status)
        {
            Status2.Invoke(new UpdateStatusDelegate(delegate(string s) { StatusLabel.Text = s; }), new object[] { status });
        }

        private void Stop_Click(object sender, EventArgs e)
        {
            rs.Stop = true;
            //rs.Finish();
            //rs.VoiceCleanUp();
            stop = true;
        }

        public void SetBitmap(int index, int width, int height, byte[] pixels)
        {
            if (pixels == null) return;
            lock (this)
            {
                if (bitmaps[index] != null) bitmaps[index].Dispose();
                bitmaps[index] = new Bitmap(width, height, PixelFormat.Format32bppRgb);
                BitmapData data = bitmaps[index].LockBits(new Rectangle(0, 0, width, height), ImageLockMode.WriteOnly, PixelFormat.Format32bppRgb);
                Marshal.Copy(pixels, 0, data.Scan0, width * height * 4);
                bitmaps[index].UnlockBits(data);
            }
        }
        int index = 0;
        private void Panel_Paint(object sender, PaintEventArgs e)
        {
            lock (this)
            {
               // int index=(sender == MainPanel) ? 0 : 1;
                Bitmap bitmap = bitmaps[index];
                if (bitmap == null) return;
                if (Scale2.Checked || sender==PIPPanel)
                {
                    /* Keep the aspect ratio */
                    Rectangle rc = (sender as PictureBox).ClientRectangle;
                    float xscale = (float)rc.Width / (float)bitmap.Width;
                    float yscale = (float)rc.Height / (float)bitmap.Height;
                    float xyscale = (xscale < yscale) ? xscale : yscale;
                    int width = (int)(bitmap.Width * xyscale);
                    int height = (int)(bitmap.Height * xyscale);
                    rc.X = (rc.Width - width) / 2;
                    rc.Y = (rc.Height - height) / 2;
                    rc.Width = width;
                    rc.Height = height;
                    e.Graphics.DrawImage(bitmap, rc);
                }
                else
                {
                    e.Graphics.DrawImageUnscaled(bitmap, 0, 0);
                }
            }
        }

        private delegate void UpdatePanelDelegate();
        public void UpdatePanel()
        {
            MainPanel.Invoke(new UpdatePanelDelegate(delegate()
                { MainPanel.Invalidate(); PIPPanel.Invalidate(); }));
        }

        private void CheckSelection()
        {
            PXCMCapture.Device.StreamProfile cprofile=GetColorConfiguration();
            DepthNone.Enabled=(cprofile.imageInfo.format!=0);
            PXCMCapture.Device.StreamProfile dprofile=GetDepthConfiguration();
            ColorNone.Enabled=(dprofile.imageInfo.format!=0);
            
            Color.Enabled = !ColorNone.Checked;
            Depth.Enabled = !DepthNone.Checked;
            PIP.Enabled = !DepthNone.Checked && !ColorNone.Checked; 

            for (int i = 0; i < 5; i++)
            {
                if (Color.Checked && !Color.Enabled) Depth.Checked = true;
            }
        }

        public string GetFileName()
        {
            return filename;
        }

        public bool IsModeLive()
        {
            return ModeLive.Checked;
        }

        public bool IsModeReocrd()
        {
            return ModeRecord.Checked;
        }

        private void ModeLive_Click(object sender, EventArgs e)
        {
            ModeLive.Checked = true;
            ModePlayback.Checked = ModeRecord.Checked = false;
            PopulateDeviceMenu();
        }

        private void ModePlayback_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "All files (*.*)|*.*";
            ofd.CheckFileExists = true;
            ofd.CheckPathExists = true;
            filename=(ofd.ShowDialog() == DialogResult.OK)?ofd.FileName:null;
            ofd.Dispose();
            if (filename == null)
            {
                ModeLive.Checked = true;
                ModePlayback.Checked = ModeRecord.Checked = false;
                PopulateDeviceMenu();
            } 
            else 
            {
                ModePlayback.Checked = true;
                ModeLive.Checked = ModeRecord.Checked = false;
                if (PopulateDeviceFromFileMenu() == false)
                {
                    ModeLive.Checked = true;
                    ModePlayback.Checked = ModeRecord.Checked = false;
                }
            }
        }

        private void ModeRecord_Click(object sender, EventArgs e)
        {
            ModeRecord.Checked = true;
            ModeLive.Checked = ModePlayback.Checked = false;
            PopulateDeviceMenu();

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "All files (*.*)|*.*";
            sfd.CheckPathExists = true;
            sfd.OverwritePrompt = true;
            try
            {
                filename = (sfd.ShowDialog() == DialogResult.OK) ? sfd.FileName : null;
            }
            catch
            {
                sfd.Dispose();
            }
            sfd.Dispose();
        }

        private void PIP_CheckStateChanged(object sender, EventArgs e)
        {
            Rectangle rc;
            switch (PIP.CheckState)
            {
                case CheckState.Checked:
                    rc= MainPanel.Bounds;
                    rc.Width = rc.Width / 2;
                    rc.X = rc.X + rc.Width;
                    rc.Height = rc.Height / 2;
                    rc.Y = rc.Y + rc.Height;
                    PIPPanel.Bounds=rc;
                    PIPPanel.Show();
                    break;
                case CheckState.Indeterminate:
                    rc= MainPanel.Bounds;
                    rc.X = rc.X + rc.Width * 3 / 4;
                    rc.Y = rc.Y + rc.Height * 3 / 4;
                    rc.Width = rc.Width / 4;
                    rc.Height = rc.Height / 4;
                    PIPPanel.Bounds=rc;
                    PIPPanel.Show();
                    break;
                case CheckState.Unchecked:
                    PIPPanel.Hide();
                    break;
            }
        }

        public bool GetStopState()
        {
            return stop;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void ColorMenu_Click(object sender, EventArgs e)
        {

        }

        private void Segmented_CheckedChanged(object sender, EventArgs e)
        {
            secondary = primary;
            primary = 2;
        }

        private void Color_CheckedChanged(object sender, EventArgs e)
        {
            secondary = primary;
            primary = 0;
        }

        private void Depth_CheckedChanged(object sender, EventArgs e)
        {
            secondary = primary;
            primary = 1;
        }
        bool connected = false;
        uPLibrary.Networking.M2Mqtt.MqttClient mqtt = null;
        string topic = "";
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                topic = txtChannel.Text;
               
                mqtt = new uPLibrary.Networking.M2Mqtt.MqttClient(txtAddress.Text);
                var bt=mqtt.Connect("RUPAM_DAS_LAPTOP");
                
                if (mqtt != null && mqtt.IsConnected)
                {
                    connected = true;
                    MessageBox.Show("Connected Successfully");

                }
                else
                {
                    MessageBox.Show("Could Not Connect");
                }
            }
            catch
            {
                MessageBox.Show("Could Not Connect");
            }
            
        }
        string lastGesture = "";
        string gesture = "";
        double lastY = 0;
        public void HandGestureTocar(double x,double y,double z,int openness)
        {
            
            if (openness > 30)
            {
                
                //if (Math.Abs(lastY - y) > 60)
                {
                    
                      if (x < 250 )
                        {
                            gesture = "LEFT";
                        }
                      else if (x > 420)
                      {
                          gesture = "RIGHT";
                      }
                      else
                      {
                          if (Math.Abs(z) < 28)
                          {
                              if (lastGesture.Equals("LEFT") || lastGesture.Equals("RIGHT"))
                              {
                                  gesture = "NO";
                              }
                              else
                              {
                                  gesture = "FORWARD";
                              }
                          }
                          if (Math.Abs(z) > 40)
                          {
                              if (lastGesture.Equals("LEFT") || lastGesture.Equals("RIGHT"))
                              {
                                  gesture = "NO";
                              }
                              else
                              {
                                  gesture = "REVERSE";
                              }
                          }
                      }
                        
                        
                   
                    lastY = y;
                }
            }
            else
            {
                lastY = 0;
                if(!TheUltimateRealSenseClass.isVoiceGesture)
                gesture = "STOP";
            }

            if (!gesture.Equals(lastGesture))
            {
                label1.Invoke((MethodInvoker)delegate
                {
                    label1.Text = gesture;
                });
                               
                
                if (connected )
                {
                    lastGesture = gesture;

                    lastY = 0;
                    PublishMQTTData(gesture);
                    
                }
            }
        }
        static byte[] GetBytes(string str)
        {
            byte[] bytes = new byte[str.Length ];
            char[] ar = str.ToCharArray();
            for (int i = 0; i < str.Length; i++)
            {
                bytes[i] = (byte)ar[i];
            }
            //System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }

        static string GetString(byte[] bytes)
        {
            char[] chars = new char[bytes.Length / sizeof(char)];
            System.Buffer.BlockCopy(bytes, 0, chars, 0, bytes.Length);
            return new string(chars);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            PublishMQTTData("STOP");
        }

        private void button2_Leave(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, KeyPressEventArgs e)
        {
            

        }

        private void button2_Enter(object sender, EventArgs e)
        {
            
        }

        private void button5_MouseEnter(object sender, EventArgs e)
        {
            if (!connected)
                return;
            Button b = (Button)sender;
           // mqtt.Publish("rupam/data", GetBytes(b.Text), 0, false);
            PublishMQTTData(b.Text);
        }
        string lastSent = "";
        public  void PublishMQTTData(string command)
        {
            label1.Invoke((MethodInvoker)delegate
            {
                label1.Text = command;
            });
                           
            if (connected)
            {
                if (!lastSent.Equals(command))
                {
                    if (command.Equals("STOP") || command.Equals("NO"))
                    {
                        TheUltimateRealSenseClass.isVoiceGesture = false;
                    }
                    mqtt.Publish(topic, GetBytes(command), 0, false);
                    lastSent = command;
                }
            }
        }
        private void button5_MouseLeave(object sender, EventArgs e)
        {
            //if (!connected)
              //  return;
            Button b = (Button)sender;
            if (b.Text.Equals("FORWARD") || b.Text.Equals("REVERSE"))
            {
                PublishMQTTData("STOP");

                //mqtt.Publish("rupam/data", GetBytes("STOP"));
            }
            if (b.Text.Equals("RIGHT") || b.Text.Equals("LEFT"))
            {
                PublishMQTTData("NO");
                //mqtt.Publish("rupam/data", GetBytes("NO"));
            }
        }

        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            PublishMQTTData("FORWARD");
        }
    }
}
