﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Linq;
using System.Text;
using System.Drawing;

using MyRealSenseCSharp;
using System.Collections;
using sample3dseg.cs;
using System.Drawing.Imaging;
using System.Windows.Forms;
namespace MyRealSenseCSharp
{
    enum StreamMode { LIVE, RECORD, PLAY };
    enum ColorType { COLOR, DEPTH, SEGMENTED };
    enum RsSdkState { RECORD, PLAY, LIVE };
    class TheUltimateRealSenseClass
    {
        #region variables of 3D Segmentation
        public ColorType colorType = ColorType.SEGMENTED;
        public FPSTimer timer = null;
        public StreamMode streamMode = StreamMode.LIVE;
        private PXCMSession session;
        private volatile bool closing = false;
        public bool Stop = false;
        private volatile bool stop = false;

        public int primary = 0;
        public int secondary = 1;
        private string filename = null;
        PXCMSenseManager pp;
        PXCMCapture.DeviceInfo dinfo2;
        PXCMCapture.Device.StreamProfileSet filter;
        PXCMCapture.Device.StreamProfile cinfo;
        PXCMCapture.Device.StreamProfile dinfo;
        pxcmStatus result;
        PXCMCapture.Device d;
        pxcmStatus s;
        ushort DepthConfidenceThreshold;
        int IVCAMLaserPower;
        PXCMCapture.Device.IVCAMAccuracy IVCAMAccuracy;
        int IVCAMMotionRangeTradeOff;
        int IVCAMFilterOption;
        PXCMCapture.Device.MirrorMode MirrorMode;
        PXCMCapture.Sample sample;
        bool sts;
        Projection projection;
        #endregion
        
        #region All Hand Recognition Variables
        PXCMCapture.DeviceInfo dinfoH;
        byte[] LUT;
        // private MainForm form;
        private bool _disconnected = false;
        //Queue containing depth image - for synchronization purposes
        private Queue<PXCMImage> m_images;
        private const int NumberOfFramesToDelay = 3;
        private int _framesCounter = 0;
        private float _maxRange;
        public string deviceName = "";
        public ArrayList allGestures = null;
        bool init = false;
        public double MaxRange = 0;
  
        public bool isLabel = true;
        public bool isJoint = true;
        public bool isSkeleton = true;
        public bool isDepth = true;

        public Bitmap labeledBitmap = null;
        public Bitmap depthBitmap = null;
        public PXCMHandData.GestureData gestureData;
        public int firedGesturesNumber = 0;
        public string gestureStatusLeft = string.Empty;
        public string gestureStatusRight = string.Empty;
        public PXCMHandData.IHand ihandData;
        public string infoS = "";
        public Color infoColor = Color.Green;
        public string statusS = "";
        public RsSdkState curState = RsSdkState.LIVE;
        public int[] HandOpen = new int[] { 0, 0 };
        double posX = -1, posY = -1, posZ = -1;
        /////////////////////////////
        public Dictionary<string, PXCMCapture.DeviceInfo> Devices { get; set; }
        bool liveCamera = false;
        PXCMSenseManager instance = null;
        bool flag = true;
        private pxcmStatus status;
        PXCMCapture.DeviceInfo info;
        PXCMSenseManager.Handler handler;
        PXCMHandConfiguration handConfiguration = null;
        public PXCMHandData handData = null;
        public PXCMSession g_session;
        
        PXCMHandModule handAnalysis;
        ArrayList gestureNames;
        PXCMCapture.Device device;
        public int frameCounter = 0;
        int frameNumber = 0;
       
        public PXCMHandData.JointData[][] nodes = null;
        public PXCMHandData.JointData jointData;
        public int numOfHands = 0;
        public PXCMHandData.AlertData alertData;
        /// <summary>
        /// ///////////////////////////
        /// </summary>
        /// <param name="form"></param>
        #endregion 

        #region Model, Language Device variables
        private Dictionary<string, PXCMCapture.DeviceInfo> devices = new Dictionary<string, PXCMCapture.DeviceInfo>();
        private Dictionary<string, int> devices_iuid = new Dictionary<string, int>();
        private Dictionary<string, PXCMCapture.Device.StreamProfile> profiles = new Dictionary<string, PXCMCapture.Device.StreamProfile>();
        private Dictionary<string, PXCMCapture.Device.StreamProfile> dprofiles = new Dictionary<string, PXCMCapture.Device.StreamProfile>();
       
        
        ///////////////////////////////////   VOICE
        public Dictionary<string, Int32> vModules = new Dictionary<string, int>();
        private Dictionary<string, PXCMAudioSource.DeviceInfo> vDevices = new Dictionary<string, PXCMAudioSource.DeviceInfo>();
        string selectedVdevice = "";
        string selectedVmodule = "";
        List<string> Languages = new List<string>();
        string[] modelNames;
        
        ////////////////////////////////////// SPEECH/////////////////////////////////////////////

        List<string> speechModules = new List<string>();
        int selectedSpeechLanguage = 0;
        List<string> speechLanguages = new List<string>();
         ///////////////////////////////////////////////////////////////////
        
        
        #endregion
        #region voice recognition variables
        PXCMAudioSource source;
        PXCMSpeechRecognition sr;
        public string[] cmds = new string[] { "STRAIGHT FORWARD", "STOP STOP", "NO NO", "MOVE RIGHT", "MOVE LEFT", "COME REVERSE" };
        #endregion
        #region speech synthesis variables
      
        public string curr_module_name;
        public uint curr_language;
        public int curr_volume;
        public int curr_pitch;
        public int curr_speech_rate;
       
        #endregion
        #region variables for Emotion and facial tracking
        public PXCMEmotion   emotionData = null;
        public string[] EmotionLabels = { "ANGER", "CONTEMPT", "DISGUST", "FEAR", "JOY", "SADNESS", "SURPRISE" };
       public string[] SentimentLabels = { "NEGATIVE", "POSITIVE", "NEUTRAL" };

        public int NUM_EMOTIONS = 10;
        public int NUM_PRIMARY_EMOTIONS = 7;
        PXCMFaceModule faceModule = null;
        #endregion
        private MainForm form;
        List<string> deviceList = new List<string>();
        string selectedDevice = "";
        string selectedProfile = "";
        string selectedDProfile = "";

        #region Populatre All device, Language, Models
        private string LanguageToString(PXCMSpeechRecognition.LanguageType language)
        {
            switch (language)
            {
                case PXCMSpeechRecognition.LanguageType.LANGUAGE_US_ENGLISH: return "US English";
                case PXCMSpeechRecognition.LanguageType.LANGUAGE_GB_ENGLISH: return "British English";
                case PXCMSpeechRecognition.LanguageType.LANGUAGE_DE_GERMAN: return "Deutsch";
                case PXCMSpeechRecognition.LanguageType.LANGUAGE_IT_ITALIAN: return "Italiano";
                case PXCMSpeechRecognition.LanguageType.LANGUAGE_BR_PORTUGUESE: return "Português";
                case PXCMSpeechRecognition.LanguageType.LANGUAGE_CN_CHINESE: return "中文";
                case PXCMSpeechRecognition.LanguageType.LANGUAGE_FR_FRENCH: return "Français";
                case PXCMSpeechRecognition.LanguageType.LANGUAGE_JP_JAPANESE: return "日本語";
                case PXCMSpeechRecognition.LanguageType.LANGUAGE_US_SPANISH: return "US Español";
                case PXCMSpeechRecognition.LanguageType.LANGUAGE_LA_SPANISH: return "LA Español";
            }
            return null;
        }
        private string LanguageToString(PXCMSpeechSynthesis.LanguageType language)
        {
            switch (language)
            {
                case PXCMSpeechSynthesis.LanguageType.LANGUAGE_US_ENGLISH: return "US English";
                case PXCMSpeechSynthesis.LanguageType.LANGUAGE_GB_ENGLISH: return "British English";
                case PXCMSpeechSynthesis.LanguageType.LANGUAGE_DE_GERMAN: return "Deutsch";
                case PXCMSpeechSynthesis.LanguageType.LANGUAGE_IT_ITALIAN: return "Italiano";
                case PXCMSpeechSynthesis.LanguageType.LANGUAGE_BR_PORTUGUESE: return "Português";
                case PXCMSpeechSynthesis.LanguageType.LANGUAGE_CN_CHINESE: return "中文";
                case PXCMSpeechSynthesis.LanguageType.LANGUAGE_FR_FRENCH: return "Français";
                case PXCMSpeechSynthesis.LanguageType.LANGUAGE_JP_JAPANESE: return "日本語";
                case PXCMSpeechSynthesis.LanguageType.LANGUAGE_US_SPANISH: return "US Español";
                case PXCMSpeechSynthesis.LanguageType.LANGUAGE_LA_SPANISH: return "LA Español";
            }
            return null;
        }
        private void PopulateDeviceMenu()
        {
            devices.Clear();
            devices_iuid.Clear();

            PXCMSession.ImplDesc desc = new PXCMSession.ImplDesc();
            desc.group = PXCMSession.ImplGroup.IMPL_GROUP_SENSOR;
            desc.subgroup = PXCMSession.ImplSubgroup.IMPL_SUBGROUP_VIDEO_CAPTURE;


            for (int i = 0; ; i++)
            {
                PXCMSession.ImplDesc desc1;
                if (session.QueryImpl(desc, i, out desc1) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                PXCMCapture capture;
                if (session.CreateImpl<PXCMCapture>(desc1, out capture) < pxcmStatus.PXCM_STATUS_NO_ERROR) continue;
                for (int j = 0; ; j++)
                {
                    PXCMCapture.DeviceInfo dinfo;
                    if (capture.QueryDeviceInfo(j, out dinfo) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                    if (dinfo.model != PXCMCapture.DeviceModel.DEVICE_MODEL_IVCAM) continue;

                    string sm1 = dinfo.name;
                    if (sm1.ToLower().Contains("realsense"))
                        selectedDevice = sm1;
                    devices[sm1] = dinfo;
                    devices_iuid[sm1] = desc1.iuid;
                    deviceList.Add(sm1);
                }
                capture.Dispose();
            }


            //    PopulateColorMenus(DeviceMenu.DropDownItems[0] as ToolStripMenuItem);
            //  PopulateDepthMenus(DeviceMenu.DropDownItems[0] as ToolStripMenuItem);
        }
        private string ProfileToString(PXCMCapture.Device.StreamProfile pinfo)
        {
            string line = pinfo.imageInfo.format.ToString().Substring(13) + " " + pinfo.imageInfo.width + "x" + pinfo.imageInfo.height + " ";
            if (pinfo.frameRate.min != pinfo.frameRate.max)
            {
                line += (float)pinfo.frameRate.min + "-" +
                      (float)pinfo.frameRate.max;
            }
            else
            {
                float fps = (pinfo.frameRate.min != 0) ? pinfo.frameRate.min : pinfo.frameRate.max;
                line += fps;
            }
            return line;
        }
        private void PopulateColorMenus()
        {
            string device_item = selectedDevice;
            PXCMSession.ImplDesc desc = new PXCMSession.ImplDesc();
            desc.group = PXCMSession.ImplGroup.IMPL_GROUP_SENSOR;
            desc.subgroup = PXCMSession.ImplSubgroup.IMPL_SUBGROUP_VIDEO_CAPTURE;
            desc.iuid = devices_iuid[device_item];
            desc.cuids[0] = PXCMCapture.CUID;

            profiles.Clear();

            PXCMCapture capture;
            PXCMCapture.DeviceInfo dinfo2 = devices[selectedDevice];

            PXCMSenseManager pp = session.CreateSenseManager();
            if (pp == null) return;
            if (pp.Enable3DSeg() < pxcmStatus.PXCM_STATUS_NO_ERROR) return;
            PXCM3DSeg s = pp.Query3DSeg();
            if (s == null) return;
            PXCMVideoModule m = s.QueryInstance<PXCMVideoModule>();
            if (m == null) return;

            if (session.CreateImpl<PXCMCapture>(desc, out capture) >= pxcmStatus.PXCM_STATUS_NO_ERROR)
            {
                PXCMCapture.Device device = capture.CreateDevice(dinfo2.didx);
                if (device != null)
                {
                    PXCMCapture.Device.StreamProfileSet profile = new PXCMCapture.Device.StreamProfileSet(); ;
                    if (((int)dinfo2.streams & (int)PXCMCapture.StreamType.STREAM_TYPE_COLOR) != 0)
                    {
                        for (int p = 0; ; p++)
                        {
                            if (device.QueryStreamProfileSet(PXCMCapture.StreamType.STREAM_TYPE_COLOR, p, out profile) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                            PXCMCapture.Device.StreamProfile sprofile = profile[PXCMCapture.StreamType.STREAM_TYPE_COLOR];

                            // Only populate profiles which are supported by the module
                            bool bFound = false;
                            int i = 0;
                            PXCMVideoModule.DataDesc inputs;
                            while (!bFound
                                && (m.QueryCaptureProfile(i++, out inputs) >= pxcmStatus.PXCM_STATUS_NO_ERROR))
                            {
                                if ((sprofile.imageInfo.height == inputs.streams.color.sizeMax.height)
                                    && (sprofile.imageInfo.width == inputs.streams.color.sizeMax.width)
                                    && (sprofile.frameRate.max == inputs.streams.color.frameRate.max))
                                {
                                    bFound = true;
                                }
                            }
                            if (bFound)
                            {
                                string sm1 = ProfileToString(sprofile);
                                profiles[sm1] = sprofile;
                                if (sm1.Contains("RGB24") && sm1.Contains("640") && sm1.Contains("480"))//selectedProfile.Length < 2
                                {
                                    selectedProfile = sm1;
                                }

                            }
                        }
                    }
                    device.Dispose();
                }
                capture.Dispose();
            }
            m.Dispose();
            pp.Dispose();

        }
        private void PopulateDepthMenus()
        {
            string device_item = selectedDevice;
            PXCMSession.ImplDesc desc = new PXCMSession.ImplDesc();
            desc.group = PXCMSession.ImplGroup.IMPL_GROUP_SENSOR;
            desc.subgroup = PXCMSession.ImplSubgroup.IMPL_SUBGROUP_VIDEO_CAPTURE;
            desc.iuid = devices_iuid[device_item];
            desc.cuids[0] = PXCMCapture.CUID;


            PXCMCapture capture;
            PXCMCapture.DeviceInfo dinfo2 = devices[selectedDevice];

            PXCMSenseManager pp = session.CreateSenseManager();
            if (pp == null) return;
            if (pp.Enable3DSeg() < pxcmStatus.PXCM_STATUS_NO_ERROR) return;
            PXCM3DSeg s = pp.Query3DSeg();
            if (s == null) return;
            PXCMVideoModule m = s.QueryInstance<PXCMVideoModule>();
            if (m == null) return;

            if (session.CreateImpl<PXCMCapture>(desc, out capture) >= pxcmStatus.PXCM_STATUS_NO_ERROR)
            {
                PXCMCapture.Device device = capture.CreateDevice(dinfo2.didx);
                if (device != null)
                {
                    PXCMCapture.Device.StreamProfileSet profile = new PXCMCapture.Device.StreamProfileSet(); ;
                    PXCMCapture.Device.StreamProfile color_profile = profiles[selectedProfile];
                    if (((int)dinfo2.streams & (int)PXCMCapture.StreamType.STREAM_TYPE_DEPTH) != 0)
                    {
                        for (int p = 0; ; p++)
                        {
                            if (device.QueryStreamProfileSet(PXCMCapture.StreamType.STREAM_TYPE_DEPTH, p, out profile) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                            PXCMCapture.Device.StreamProfile sprofile = profile[PXCMCapture.StreamType.STREAM_TYPE_DEPTH];

                            bool bFound = false;
                            int i = 0;
                            PXCMVideoModule.DataDesc inputs;
                            while (!bFound
                                && (m.QueryCaptureProfile(i++, out inputs) >= pxcmStatus.PXCM_STATUS_NO_ERROR))
                            {
                                if ((sprofile.imageInfo.height == inputs.streams.depth.sizeMax.height)
                                    && (sprofile.imageInfo.width == inputs.streams.depth.sizeMax.width)
                                    && (sprofile.frameRate.max == inputs.streams.depth.frameRate.max)
                                    && (color_profile.frameRate.max == inputs.streams.depth.frameRate.max))
                                {
                                    bFound = true;
                                }
                            }
                            if (bFound)
                            {
                                string sm1 = ProfileToString(sprofile);
                                dprofiles[sm1] = sprofile;
                                if (selectedDProfile.Length < 2)
                                {
                                    selectedDProfile = sm1;
                                }

                            }
                        }
                    }
                    device.Dispose();
                }
                capture.Dispose();
            }
            m.Dispose();
            pp.Dispose();


        }
        public string[] PopulateModuleMenu()
        {
            PXCMSession.ImplDesc desc = new PXCMSession.ImplDesc();
            desc.cuids[0] = PXCMHandModule.CUID;

            List<string> al = new List<string>();
            for (int i = 0; ; i++)
            {
                PXCMSession.ImplDesc desc1;
                if (session.QueryImpl(desc, i, out desc1) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                al.Add(desc1.friendlyName);
            }
            return al.ToArray();
        }
        private void PropogateSpeechModule()
        {
            PXCMSession.ImplDesc desc = new PXCMSession.ImplDesc();
            desc.cuids[0] = PXCMSpeechSynthesis.CUID;

            for (int i = 0; ; i++)
            {
                PXCMSession.ImplDesc desc1;
                if (session.QueryImpl(desc, i, out desc1) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                speechModules.Add(desc1.friendlyName);

            }

        }
        private void PropogateSpeechLanguage()
        {


            PXCMSession.ImplDesc desc = new PXCMSession.ImplDesc();
            desc.cuids[0] = PXCMSpeechSynthesis.CUID;
            desc.friendlyName = speechModules[0];
            PXCMSpeechSynthesis vsynth;
            if (session.CreateImpl<PXCMSpeechSynthesis>(desc, out vsynth) >= pxcmStatus.PXCM_STATUS_NO_ERROR)
            {
                for (int i = 0; ; i++)
                {
                    PXCMSpeechSynthesis.ProfileInfo pinfo;
                    if (vsynth.QueryProfile(i, out pinfo) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;

                    speechLanguages.Add(LanguageToString(pinfo.language));

                }
                vsynth.Dispose();
            }


        }

            #region voice recognition part
        private void PopulateVoiceSource()
        {

            vDevices.Clear();

            PXCMAudioSource source = session.CreateAudioSource();
            if (source != null)
            {
                source.ScanDevices();

                for (int i = 0; ; i++)
                {
                    PXCMAudioSource.DeviceInfo dinfo;
                    if (source.QueryDeviceInfo(i, out dinfo) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;

                    //  ToolStripMenuItem sm1 = new ToolStripMenuItem(dinfo.name, null, new EventHandler(Source_Item_Click));
                    vDevices[dinfo.name] = dinfo;
                   // if (dinfo.name.ToLower().Contains("creative"))
                    {
                        selectedVdevice = dinfo.name;
                    }

                }

                source.Dispose();
            }


        }
        private void PopulateVoiceModule()
        {

            vModules.Clear();

            PXCMSession.ImplDesc desc = new PXCMSession.ImplDesc();
            desc.cuids[0] = PXCMSpeechRecognition.CUID;
            for (int i = 0; ; i++)
            {
                PXCMSession.ImplDesc desc1;
                if (session.QueryImpl(desc, i, out desc1) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                vModules[desc1.friendlyName] = desc1.iuid;

                if (desc1.friendlyName.ToLower().Contains("nuance"))
                {
                    selectedVmodule = desc1.friendlyName;
                }
            }


        }
        
        private void PopulateLanguage()
        {
            PXCMSession.ImplDesc desc = new PXCMSession.ImplDesc();
            desc.cuids[0] = PXCMSpeechRecognition.CUID;
            desc.iuid = vModules[selectedVmodule];

            PXCMSpeechRecognition vrec;
            if (session.CreateImpl<PXCMSpeechRecognition>(desc, out vrec) < pxcmStatus.PXCM_STATUS_NO_ERROR) return;

            for (int i = 0; ; i++)
            {
                PXCMSpeechRecognition.ProfileInfo pinfo;
                if (vrec.QueryProfile(i, out pinfo) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                Languages.Add(LanguageToString(pinfo.language));

            }
            vrec.Dispose();

        }
            #endregion

        #endregion for Populating options
        #region Projection and Segmentation related Methods
        public static void LightenBackground(PXCMImage segmented_image)
        {
            PXCMImage.ImageData segmented_image_data;
            segmented_image.AcquireAccess(
                PXCMImage.Access.ACCESS_READ_WRITE,
                PXCMImage.PixelFormat.PIXEL_FORMAT_RGB32,
                out segmented_image_data);

            int height = segmented_image.QueryInfo().height;
            int width = segmented_image.QueryInfo().width;

            for (int y = 0; y < height; y++)
            {
                unsafe
                {
                    byte* p = (byte*)segmented_image_data.planes[0] + y * segmented_image_data.pitches[0];
                    const byte GREY = 0x7f;
                    for (int x = 0; x < width; x++)
                    {
                        if (p[3] > 0)
                        {
                            // When the user moves into the near/far extent, the alpha values will drop from 255 to 1.
                            // This can be used to fade the user in/out as a cue to move into the ideal operating range.
                            float blend_factor = (float)p[3] / (float)255;
                            for (int ch = 0; ch < 3; ch++)
                            {
                                byte not_visible = (byte)((p[ch] >> 4) + GREY);
                                p[ch] = (byte)(p[ch] * blend_factor + not_visible * (1.0f - blend_factor));
                            }
                        }
                        else for (int ch = 0; ch < 3; ch++) p[ch] = (byte)((p[ch] >> 4) + GREY);

                        p += 4;
                    }
                }
            }

            segmented_image.ReleaseAccess(segmented_image_data);
        }

        public static byte[] GetRGB32Pixels(PXCMImage image, out int cwidth, out int cheight)
        {
            PXCMImage.ImageData cdata;
            byte[] cpixels = null;
            cwidth = cheight = 0;
            if (image.AcquireAccess(PXCMImage.Access.ACCESS_READ, PXCMImage.PixelFormat.PIXEL_FORMAT_RGB32, out cdata) >= pxcmStatus.PXCM_STATUS_NO_ERROR)
            {
                cwidth = (int)cdata.pitches[0] / sizeof(Int32);
                cheight = (int)image.info.height;
                cpixels = cdata.ToByteArray(0, (int)cdata.pitches[0] * cheight);
                image.ReleaseAccess(cdata);
            }
            return cpixels;
        }
        string statText = "";

        public void SetBitmap(int index, int width, int height, byte[] pixels)
        {
            if (pixels == null) return;
            lock (this)
            {
                if (bitmaps[index] != null) bitmaps[index].Dispose();
                bitmaps[index] = new Bitmap(width, height, System.Drawing.Imaging.PixelFormat.Format32bppRgb);
                System.Drawing.Imaging.BitmapData data = bitmaps[index].LockBits(new Rectangle(0, 0, width, height), System.Drawing.Imaging.ImageLockMode.WriteOnly, System.Drawing.Imaging.PixelFormat.Format32bppRgb);
                Marshal.Copy(pixels, 0, data.Scan0, width * height * 4);
                bitmaps[index].UnlockBits(data);
            }
        }
        #endregion
        #region all Logging, Update methods
        void UpdateStatus(string s)
        {
            statText = s;
        }
        private void UpdateInfo(string s, Color c)
        {
            infoS = s;
            infoColor = c;
        }
        string alertS = "";
        void PrintStatus(string s)
        {
            alertS = s;
        }
        void OnAlert(PXCMSpeechRecognition.AlertData data)
        {
            PrintStatus(AlertToString(data.label));
        }

        public string AlertToString(PXCMSpeechRecognition.AlertType label)
        {
            switch (label)
            {
                case PXCMSpeechRecognition.AlertType.ALERT_SNR_LOW: return "SNR_LOW";
                case PXCMSpeechRecognition.AlertType.ALERT_SPEECH_UNRECOGNIZABLE: return "SPEECH_UNRECOGNIZABLE";
                case PXCMSpeechRecognition.AlertType.ALERT_VOLUME_HIGH: return "VOLUME_HIGH";
                case PXCMSpeechRecognition.AlertType.ALERT_VOLUME_LOW: return "VOLUME_LOW";
                case PXCMSpeechRecognition.AlertType.ALERT_SPEECH_BEGIN: return "SPEECH_BEGIN";
                case PXCMSpeechRecognition.AlertType.ALERT_SPEECH_END: return "SPEECH_END";
                case PXCMSpeechRecognition.AlertType.ALERT_RECOGNITION_ABORTED: return "REC_ABORT";
                case PXCMSpeechRecognition.AlertType.ALERT_RECOGNITION_END: return "REC_END";
            }
            return "Unknown";
        }
        #endregion
        #region Hand Module Related Methods
        public static pxcmStatus OnNewFrame(Int32 mid, PXCMBase module, PXCMCapture.Sample sample)
        {
            return pxcmStatus.PXCM_STATUS_NO_ERROR;
        }
        private unsafe void DisplayPicture(PXCMImage depth, PXCMHandData handAnalysis)
        {
            if (depth == null)
                return;

            PXCMImage image = depth;

            //Mask Image
            if (isLabel)
            {

                try
                {
                    labeledBitmap = new Bitmap(image.info.width, image.info.height, PixelFormat.Format32bppRgb);
                }
                catch (Exception)
                {
                    image.Dispose();
                    return;
                }

                for (int j = 0; j < handAnalysis.QueryNumberOfHands(); j++)
                {
                    int id;
                    PXCMImage.ImageData data;

                    handAnalysis.QueryHandId(PXCMHandData.AccessOrderType.ACCESS_ORDER_BY_TIME, j, out id);
                    //Get hand by time of appearance

                    handAnalysis.QueryHandData(PXCMHandData.AccessOrderType.ACCESS_ORDER_BY_TIME, j, out ihandData);
                    if (ihandData != null &&
                        (ihandData.QuerySegmentationImage(out image) >= pxcmStatus.PXCM_STATUS_NO_ERROR))
                    {
                        if (image.AcquireAccess(PXCMImage.Access.ACCESS_READ, PXCMImage.PixelFormat.PIXEL_FORMAT_Y8,
                            out data) >= pxcmStatus.PXCM_STATUS_NO_ERROR)
                        {
                            Rectangle rect = new Rectangle(0, 0, image.info.width, image.info.height);

                            BitmapData bitmapdata = labeledBitmap.LockBits(rect, ImageLockMode.ReadWrite, labeledBitmap.PixelFormat);
                            byte* numPtr = (byte*)bitmapdata.Scan0; //dst
                            byte* numPtr2 = (byte*)data.planes[0]; //row
                            int imagesize = image.info.width * image.info.height;
                            byte num2 = (byte)ihandData.QueryBodySide();

                            byte tmp = 0;
                            for (int i = 0; i < imagesize; i++, numPtr += 4, numPtr2++)
                            {
                                tmp = (byte)(LUT[numPtr2[0]] * num2 * 100);
                                numPtr[0] = (Byte)(tmp | numPtr[0]);
                                numPtr[1] = (Byte)(tmp | numPtr[1]);
                                numPtr[2] = (Byte)(tmp | numPtr[2]);
                                numPtr[3] = 0xff;
                            }

                            bool isError = false;

                            try
                            {
                                labeledBitmap.UnlockBits(bitmapdata);

                            }
                            catch (Exception)
                            {
                                isError = true;
                            }
                            try
                            {
                                image.ReleaseAccess(data);
                            }
                            catch (Exception)
                            {
                                isError = true;
                            }

                            if (isError)
                            {
                                labeledBitmap.Dispose();
                                image.Dispose();
                                return;
                            }

                        }
                    }
                }
                if (labeledBitmap != null)
                {
                    // form.DisplayBitmap(labeledBitmap);
                    //labeledBitmap.Dispose();
                }
                image.Dispose();

            }//end label image

            //Depth Image
            else
            {
                //collecting 3 images inside a queue and displaying the oldest image
                PXCMImage.ImageInfo info;
                PXCMImage image2;

                info = image.QueryInfo();
                image2 = g_session.CreateImage(info);
                image2.CopyImage(image);
                m_images.Enqueue(image2);
                if (m_images.Count == NumberOfFramesToDelay)
                {

                    try
                    {
                        depthBitmap = new Bitmap(image.info.width, image.info.height, PixelFormat.Format32bppRgb);
                    }
                    catch (Exception)
                    {
                        image.Dispose();
                        PXCMImage queImage = m_images.Dequeue();
                        queImage.Dispose();
                        return;
                    }

                    PXCMImage.ImageData data3;
                    PXCMImage image3 = m_images.Dequeue();
                    if (image3.AcquireAccess(PXCMImage.Access.ACCESS_READ, PXCMImage.PixelFormat.PIXEL_FORMAT_DEPTH, out data3) >= pxcmStatus.PXCM_STATUS_NO_ERROR)
                    {
                        float fMaxValue = _maxRange;
                        byte cVal;

                        Rectangle rect = new Rectangle(0, 0, image.info.width, image.info.height);
                        BitmapData bitmapdata = depthBitmap.LockBits(rect, ImageLockMode.ReadWrite, depthBitmap.PixelFormat);

                        byte* pDst = (byte*)bitmapdata.Scan0;
                        short* pSrc = (short*)data3.planes[0];
                        int size = image.info.width * image.info.height;

                        for (int i = 0; i < size; i++, pSrc++, pDst += 4)
                        {
                            cVal = (byte)((*pSrc) / fMaxValue * 255);
                            if (cVal != 0)
                                cVal = (byte)(255 - cVal);

                            pDst[0] = cVal;
                            pDst[1] = cVal;
                            pDst[2] = cVal;
                            pDst[3] = 255;
                        }
                        try
                        {
                            depthBitmap.UnlockBits(bitmapdata);
                        }
                        catch (Exception)
                        {
                            image3.ReleaseAccess(data3);
                            depthBitmap.Dispose();
                            image3.Dispose();
                            return;
                        }

                        //form.DisplayBitmap(depthBitmap);
                        image3.ReleaseAccess(data3);
                    }
                    depthBitmap.Dispose();
                    image3.Dispose();
                }
            }
        }
        public Bitmap DisplayJoints(PXCMHandData.JointData[][] nodes, int numOfHands, Bitmap bitmap, bool jointShow, bool skelShow, bool labelMap)
        {
            if (bitmap == null) return null;
            if (nodes == null) return bitmap;

            if (jointShow || skelShow)
            {
                lock (bitmap)
                {
                    int scaleFactor = 1;

                    Graphics g = Graphics.FromImage(bitmap);

                    using (Pen boneColor = new Pen(Color.DodgerBlue, 3.0f))
                    {
                        for (int i = 0; i < numOfHands; i++)
                        {
                            if (nodes[i][0] == null) continue;
                            int baseX = (int)nodes[i][0].positionImage.x / scaleFactor;
                            int baseY = (int)nodes[i][0].positionImage.y / scaleFactor;

                            int wristX = (int)nodes[i][0].positionImage.x / scaleFactor;
                            int wristY = (int)nodes[i][0].positionImage.y / scaleFactor;

                            if (skelShow)
                            {
                                for (int j = 1; j < 22; j++)
                                {
                                    if (nodes[i][j] == null) continue;
                                    int x = (int)nodes[i][j].positionImage.x / scaleFactor;
                                    int y = (int)nodes[i][j].positionImage.y / scaleFactor;

                                    if (nodes[i][j].confidence <= 0) continue;

                                    if (j == 2 || j == 6 || j == 10 || j == 14 || j == 18)
                                    {

                                        baseX = wristX;
                                        baseY = wristY;
                                    }

                                    g.DrawLine(boneColor, new Point(baseX, baseY), new Point(x, y));
                                    g.DrawString(j + "", new System.Drawing.Font(new FontFamily("Tahoma"), 12), new SolidBrush(Color.Red), new Point(x, y));
                                    baseX = x;
                                    baseY = y;
                                }
                            }

                            if (jointShow)
                            {
                                using (
                                    Pen red = new Pen(Color.Red, 3.0f),
                                        black = new Pen(Color.Black, 3.0f),
                                        green = new Pen(Color.Green, 3.0f),
                                        blue = new Pen(Color.Blue, 3.0f),
                                        cyan = new Pen(Color.Cyan, 3.0f),
                                        yellow = new Pen(Color.Yellow, 3.0f),
                                        orange = new Pen(Color.Orange, 3.0f))
                                {
                                    Pen currnetPen = black;

                                    for (int j = 0; j < PXCMHandData.NUMBER_OF_JOINTS; j++)
                                    {
                                        float sz = 4;
                                        if (labelMap)
                                            sz = 2;

                                        int x = (int)nodes[i][j].positionImage.x / scaleFactor;
                                        int y = (int)nodes[i][j].positionImage.y / scaleFactor;

                                        if (nodes[i][j].confidence <= 0) continue;

                                        //Wrist
                                        if (j == 0)
                                        {
                                            currnetPen = black;
                                        }

                                        //Center
                                        if (j == 1)
                                        {
                                            currnetPen = red;
                                            sz += 4;
                                        }

                                        //Thumb
                                        if (j == 2 || j == 3 || j == 4 || j == 5)
                                        {
                                            currnetPen = green;
                                        }
                                        //Index Finger
                                        if (j == 6 || j == 7 || j == 8 || j == 9)
                                        {
                                            currnetPen = blue;
                                        }
                                        //Finger
                                        if (j == 10 || j == 11 || j == 12 || j == 13)
                                        {
                                            currnetPen = yellow;
                                        }
                                        //Ring Finger
                                        if (j == 14 || j == 15 || j == 16 || j == 17)
                                        {
                                            currnetPen = cyan;
                                        }
                                        //Pinkey
                                        if (j == 18 || j == 19 || j == 20 || j == 21)
                                        {
                                            currnetPen = orange;
                                        }


                                        if (j == 5 || j == 9 || j == 13 || j == 17 || j == 21)
                                        {
                                            sz += 12;
                                            //currnetPen.Width = 1;
                                        }

                                        g.DrawEllipse(currnetPen, x - sz / 2, y - sz / 2, sz, sz);
                                    }
                                }
                            }



                        }

                    }
                    g.Dispose();
                    // bitmap.Save(gr.frameCounter + ".jpeg", System.Drawing.Imaging.ImageFormat.Jpeg);
                }
            }
            return bitmap;
        }
        #endregion
        #region voice recognition Modules, Methods and codes
        public void VoiceCleanUp()
        {
            if (sr != null)
            {
                sr.StopRec();
                sr.Dispose();
                sr = null;
            }
            if (source != null)
            {
                source.Dispose();
                source = null;
            }
        }
        public void OneTimeInitVoice(PXCMSession session)
        {


            /* Create the AudioSource instance */
            source = session.CreateAudioSource();

            if (source == null)
            {
                VoiceCleanUp();
                PrintStatus("Stopped");
                return;
            }

            /* Set audio volume to 0.2 */
            source.SetVolume(0.2f);

            /* Set Audio Source */
            source.SetDevice(vDevices[selectedVdevice]);

            /* Set Module */
            PXCMSession.ImplDesc mdesc = new PXCMSession.ImplDesc();
            mdesc.iuid = vModules[selectedVmodule];

            pxcmStatus sts = session.CreateImpl<PXCMSpeechRecognition>(out sr);
            if (sts >= pxcmStatus.PXCM_STATUS_NO_ERROR)
            {
                /* Configure */
                PXCMSpeechRecognition.ProfileInfo pinfo;
                sr.QueryProfile(0, out pinfo);
                sr.SetProfile(pinfo);




                if (cmds != null && cmds.GetLength(0) != 0)
                {
                    // voice commands available, use them
                    sr.BuildGrammarFromStringList(1, cmds, null);
                    sr.SetGrammar(1);
                }


                /* Initialization */
                PrintStatus("Init Started");
                PXCMSpeechRecognition.Handler handler = new PXCMSpeechRecognition.Handler();
                handler.onRecognition = OnRecognition;
                handler.onAlert = OnAlert;

                sts = sr.StartRec(source, handler);
                if (sts >= pxcmStatus.PXCM_STATUS_NO_ERROR)
                {
                    PrintStatus("Init OK");

                    /* Wait until the stop button is clicked */
                    

                   
                }
                else
                {
                    PrintStatus("Failed to initialize");
                }
            }
            else
            {
                PrintStatus("Init Failed");
            }

         
        }
        public static bool isVoiceGesture = false;
        public static string VoiceGesture = "";
        void OnRecognition(PXCMSpeechRecognition.RecognitionData data)
        {
          //  MessageBox.Show(data.scores[0].sentence);
            string s = data.scores[0].sentence;
            try
            {
                s = s.Split(new char[] { ' ' })[1];
                isVoiceGesture = true;
                VoiceGesture = s;

                form.PublishMQTTData(s);
                if(s.Equals("STOP")|| s.Equals("NO"))
                {
                    isVoiceGesture = false;
                }
            }
            catch { }
        }
        #endregion
        #region speech Synthesis Speak method
        public string Speak(string sentence, int curr_volume, int curr_pitch, int curr_speech_rate)
        {
            string module = speechModules[0];
            int language = selectedSpeechLanguage;
            
            PXCMSession.ImplDesc desc = new PXCMSession.ImplDesc();
            desc.friendlyName = module;
            desc.cuids[0] = PXCMSpeechSynthesis.CUID;
            PXCMSpeechSynthesis vsynth;
            pxcmStatus sts = session.CreateImpl<PXCMSpeechSynthesis>(desc, out vsynth);
            if (sts < pxcmStatus.PXCM_STATUS_NO_ERROR)
            {
                session.Dispose();
                return "Failed to create the synthesis module";
            }

            PXCMSpeechSynthesis.ProfileInfo pinfo;
            vsynth.QueryProfile(language, out pinfo);
            pinfo.volume = curr_volume;
            pinfo.rate = curr_speech_rate;
            pinfo.pitch = curr_pitch;
            sts = vsynth.SetProfile(pinfo);
            if (sts < pxcmStatus.PXCM_STATUS_NO_ERROR)
            {
                vsynth.Dispose();
                session.Dispose();
                return "Failed to initialize the synthesis module";
            }

            sts = vsynth.BuildSentence(1, sentence);
            if (sts >= pxcmStatus.PXCM_STATUS_NO_ERROR)
            {
                VoiceOut vo = new VoiceOut(pinfo.outputs);
                for (int i = 0; ; i++)
                {
                    PXCMAudio sample = vsynth.QueryBuffer(1, i);
                    if (sample == null) break;
                    vo.RenderAudio(sample);
                }
                vo.Close();
            }

            vsynth.Dispose();
            
            return null;
        }
        #endregion
        #region facial tracking methods
        public Bitmap DisplayEmotionSentimentFaceLocation(PXCMEmotion ft, Bitmap bitmap)
        {
            int numFaces = ft.QueryNumFaces();
            /*
            if (numFaces == 0)
            {
                form.PublishMQTTData("STOP");
            }*/
            for (int i = 0; i < numFaces; i++)
            {
                /* Retrieve emotionDet location data */
                PXCMEmotion.EmotionData[] arrData = new PXCMEmotion.EmotionData[NUM_EMOTIONS];
                if (ft.QueryAllEmotionData(i, out arrData) >= pxcmStatus.PXCM_STATUS_NO_ERROR)
                {
                    bitmap=DrawLocation(arrData,bitmap);
                }
            }
            return bitmap;
        }
        private Bitmap DrawLocation(PXCMEmotion.EmotionData[] data, Bitmap bitmap)
        {
            lock (this)
            {
                if (bitmap == null) return null;
                Graphics g = Graphics.FromImage(bitmap);
                Pen red = new Pen(Color.Red, 3.0f);
                Brush brush = new SolidBrush(Color.Red);
                Font font = new Font("Tahoma", 11, FontStyle.Bold);
                Brush brushTxt = new SolidBrush(Color.Cyan);
                
                    Point[] points4 = new Point[]{
                        new Point((int)data[0].rectangle.x,(int)data[0].rectangle.y),
                        new Point((int)data[0].rectangle.x+(int)data[0].rectangle.w,(int)data[0].rectangle.y),
                        new Point((int)data[0].rectangle.x+(int)data[0].rectangle.w,(int)data[0].rectangle.y+(int)data[0].rectangle.h),
                        new Point((int)data[0].rectangle.x,(int)data[0].rectangle.y+(int)data[0].rectangle.h),
                        new Point((int)data[0].rectangle.x,(int)data[0].rectangle.y)};
                    try
                    {
                        g.DrawLines(red, points4);
                    }
                    catch
                    {
                        brushTxt.Dispose();
                    }
                    //g.DrawString(data[0].fid.ToString(), font, brushTxt, (float)(data[0].rectangle.x + data[0].rectangle.w), (float)(data[0].rectangle.y));
               

                bool emotionPresent = false;
                int epidx = -1; int maxscoreE = -3; float maxscoreI = 0;
                for (int i = 0; i < NUM_PRIMARY_EMOTIONS; i++)
                {
                    if (data[i].evidence < maxscoreE) continue;
                    if (data[i].intensity < maxscoreI) continue;
                    maxscoreE = data[i].evidence;
                    maxscoreI = data[i].intensity;
                    epidx = i;
                }
                if ((epidx != -1) && (maxscoreI > 0.4))
                {
                    try
                    {
                        //form.PublishMQTTData
                        if (EmotionLabels[epidx].Equals("SURPRISE"))
                        {
                            form.PublishMQTTData("STOP");
                        }
                        g.DrawString(EmotionLabels[epidx], font, brushTxt, (float)(data[0].rectangle.x + data[0].rectangle.w), data[0].rectangle.y > 0 ? (float)data[0].rectangle.y : (float)data[0].rectangle.h - 2 * font.GetHeight());
                    }
                    catch
                    {
                        brush.Dispose();
                    }
                    emotionPresent = true;
                }

                int spidx = -1;
                if (emotionPresent)
                {
                    maxscoreE = -3; maxscoreI = 0;
                    for (int i = 0; i < (NUM_EMOTIONS - NUM_PRIMARY_EMOTIONS); i++)
                    {
                        if (data[NUM_PRIMARY_EMOTIONS + i].evidence < maxscoreE) continue;
                        if (data[NUM_PRIMARY_EMOTIONS + i].intensity < maxscoreI) continue;
                        maxscoreE = data[NUM_PRIMARY_EMOTIONS + i].evidence;
                        maxscoreI = data[NUM_PRIMARY_EMOTIONS + i].intensity;
                        spidx = i;
                    }
                    if ((spidx != -1))
                    {
                        try
                        {
                            g.DrawString(SentimentLabels[spidx], font, brushTxt, (float)(data[0].rectangle.x + data[0].rectangle.w), data[0].rectangle.y > 0 ? (float)data[0].rectangle.y + font.GetHeight() : (float)data[0].rectangle.h - font.GetHeight());
                        }
                        catch
                        {
                            red.Dispose();
                        }
                    }
                }

                brush.Dispose();
                brushTxt.Dispose();
                try
                {
                    red.Dispose();
                }
                finally
                {
                    font.Dispose();
                }
                g.Dispose();
            }
            return bitmap;
        }

        #endregion
        public Bitmap[] bitmaps = new Bitmap[2];
        public TheUltimateRealSenseClass(MainForm mf, PXCMSession session, StreamMode mode, ColorType cType)
        {
            form = mf;
            this.session = session;
            PopulateDeviceMenu();
            PopulateColorMenus();
            PopulateDepthMenus();
            modelNames = PopulateModuleMenu();// only one so default will be 0
            streamMode = mode;
            colorType = cType;
            ////////// Hand Module Part/////////////
            m_images = new Queue<PXCMImage>();
            // this.form = form;
            LUT = Enumerable.Repeat((byte)0, 256).ToArray();
            LUT[255] = 1;        
            ///////////Initializing Voice//////////////////////
            PopulateVoiceSource();
            PopulateVoiceModule();
            PopulateLanguage();
            OneTimeInitVoice(session);
            ///////////////////////////////////////////////////
            PropogateSpeechModule();
            PropogateSpeechLanguage();
            Stop = false;
        }
        
        public bool OneTimeInitializationBeforeLooping()
        {
            sts = true;

            /* Create an instance of the PXCSenseManager interface */
            pp = PXCMSenseManager.CreateInstance();
            if (pp == null)
            {
                UpdateStatus("Failed to create an SDK pipeline object");
                return false;
            }
            if (!streamMode.Equals(StreamMode.LIVE))
                pp.captureManager.SetFileName("1.rssdk", streamMode.Equals(StreamMode.RECORD));

            /* Set Input Source */
            dinfo2 = devices[selectedDevice];
            if (streamMode.Equals(StreamMode.LIVE) || streamMode.Equals(StreamMode.PLAY))
                pp.captureManager.FilterByDeviceInfo(dinfo2);

            /* Set Color & Depth Resolution */
            filter = new PXCMCapture.Device.StreamProfileSet();
            cinfo = profiles[selectedProfile];
            if (cinfo.imageInfo.format != 0)
            {
                Single cfps = cinfo.frameRate.max;
                pp.EnableStream(PXCMCapture.StreamType.STREAM_TYPE_COLOR, cinfo.imageInfo.width, cinfo.imageInfo.height, cfps);
                filter.color = cinfo;
            }

            dinfo = dprofiles[selectedDProfile];
            if (dinfo.imageInfo.format != 0)
            {
                Single dfps = dinfo.frameRate.max;
                pp.EnableStream(PXCMCapture.StreamType.STREAM_TYPE_DEPTH, dinfo.imageInfo.width, dinfo.imageInfo.height, dfps);
                filter.depth = dinfo;
            }
            pp.captureManager.FilterByStreamProfiles(filter);
            //////////////////////////// InitiaLIZING ALL Other Trackings/////////////////////////////
            #region Hand Module Initialization
            ///////////////////////////////////////////////////////////////////////
            status = pp.EnableHand(modelNames[0]);
            //////////////////////////////////////////////////////
            handAnalysis = pp.QueryHand();

            if (status != pxcmStatus.PXCM_STATUS_NO_ERROR || handAnalysis == null)
            {
                UpdateStatus("Failed Loading Module");
                return false;
            }
            handler = new PXCMSenseManager.Handler();
            handler.onModuleProcessedFrame = new PXCMSenseManager.Handler.OnModuleProcessedFrameDelegate(OnNewFrame);


            handConfiguration = handAnalysis.CreateActiveConfiguration();
            handData = handAnalysis.CreateOutput();

            if (handConfiguration == null)
            {
                UpdateStatus("Failed Create Configuration");
                return false;
            }
            if (handData == null)
            {
                UpdateStatus("Failed Create Output");
                return false;
            }
            if (init == false)
            {
                gestureNames = new ArrayList();
                int totalNumOfGestures = handConfiguration.QueryGesturesTotalNumber();
                if (totalNumOfGestures > 0)
                {

                    for (int i = 0; i < totalNumOfGestures; i++)
                    {
                        string gestureName = string.Empty;
                        if (handConfiguration.QueryGestureNameByIndex(i, out gestureName) ==
                            pxcmStatus.PXCM_STATUS_NO_ERROR)
                        {
                            gestureNames.Add(gestureName);
                        }


                    }
                    init = true;
                    // form.UpdateGesturesListSize();
                }
            }
            if (handAnalysis != null)
            {



                device = pp.captureManager.device;
                if (device != null)
                {
                     device.QueryDeviceInfo(out dinfoH);
                    if (dinfo != null && dinfoH.model == PXCMCapture.DeviceModel.DEVICE_MODEL_IVCAM)
                    {
                        device.SetDepthConfidenceThreshold(1);
                        device.SetMirrorMode(PXCMCapture.Device.MirrorMode.MIRROR_MODE_DISABLED);
                        device.SetIVCAMFilterOption(6);
                    }

                    _maxRange = device.QueryDepthSensorRange().max;

                }


                if (handConfiguration != null)
                {
                    handConfiguration.EnableAllAlerts();
                    handConfiguration.EnableSegmentationImage(true);
                    handConfiguration.EnableAllGestures();
                    handConfiguration.ApplyChanges();
                    handConfiguration.Update();
                }

                UpdateStatus("Streaming");


            }

            #endregion
            //////////////////////////////////////////////////////////////////////
            #region Facial Tracking Initialization
            pp.EnableEmotion();
            pp.EnableFace();
            #endregion
            UpdateStatus("Init Started");

            // Enable the User Segmentation video module
            result = pp.Enable3DSeg();
            if (pp.Init() >= pxcmStatus.PXCM_STATUS_NO_ERROR)
            {
                /* PXC3DSeg Video Module is tuned to work best with a particular set of device settings. */
                /* So, first we save a copy of the existing values (to restore before exit)... */
                d = pp.captureManager.device;

                DepthConfidenceThreshold = d.QueryDepthConfidenceThreshold();
                IVCAMLaserPower = d.QueryIVCAMLaserPower();
                IVCAMAccuracy = d.QueryIVCAMAccuracy();
                IVCAMMotionRangeTradeOff = d.QueryIVCAMMotionRangeTradeOff();
                IVCAMFilterOption = d.QueryIVCAMFilterOption();
                MirrorMode = d.QueryMirrorMode();

                /* ...then, change the values to the set known to work best with segmentation */
                s = d.SetDepthConfidenceThreshold(0);
                s = d.SetIVCAMLaserPower(16);
                s = d.SetIVCAMAccuracy(PXCMCapture.Device.IVCAMAccuracy.IVCAM_ACCURACY_COARSE);
                s = d.SetIVCAMMotionRangeTradeOff(21);
                s = d.SetIVCAMFilterOption(6);
                s = d.SetMirrorMode(PXCMCapture.Device.MirrorMode.MIRROR_MODE_HORIZONTAL);

                /* For UV Mapping & Projection only: Save certain properties */
                projection = new Projection(pp.session, pp.captureManager.device, dinfo.imageInfo);
                return true;
            }
            else
            {
                sts = false;
                return false;
            }
        }
        public void Finish()
        {
            Stop = true;
            timer = null;
            projection.Dispose();

            // Restore the device setting that were changed
           s = d.SetDepthConfidenceThreshold(DepthConfidenceThreshold);
            s = d.SetIVCAMLaserPower(IVCAMLaserPower);
            s = d.SetIVCAMAccuracy(IVCAMAccuracy);
            s = d.SetIVCAMMotionRangeTradeOff(IVCAMMotionRangeTradeOff);
            s = d.SetIVCAMFilterOption(IVCAMFilterOption);
            s = d.SetMirrorMode(MirrorMode);

            handData.Dispose();
            handConfiguration.Dispose();

            foreach (PXCMImage pxcmImage in m_images)
            {
                pxcmImage.Dispose();
            }

 
          
            if (flag)
            {
                UpdateStatus("Stopped");
            }
            pp.Close();
            pp.Dispose();
            if (sts) UpdateStatus("Stopped");
        }
        public bool StreamColorDepth(bool synced) /* Stream Color and Depth Synchronously or Asynchronously */
        {



            UpdateStatus("Streaming");

            /* Wait until a frame is ready: Synchronized or Asynchronous */
            if (pp.AcquireFrame(synced) < pxcmStatus.PXCM_STATUS_NO_ERROR)
            {
                projection.Dispose();
                return false;
            }
            frameCounter++;
            /* Get Segmentation image from the User Segmentation video module */
            PXCM3DSeg seg = pp.Query3DSeg();
            if (seg == null)
            {
                pp.ReleaseFrame();
                projection.Dispose();
                pp.Close();
                pp.Dispose();
                UpdateStatus("Error: 3DSeg is not available");
                return false;
            }
            PXCMImage segmented_image = seg.AcquireSegmentedImage();
            if (segmented_image == null)
            {
                pp.ReleaseFrame();
                projection.Dispose();
                pp.Close();
                pp.Dispose();
                UpdateStatus("Error: 3DSeg did not return an image");
                return false;
            }

            /* Lighen the background color channels according to the alpha channel (mask) */
            LightenBackground(segmented_image);

            /* Display images */
            PXCMCapture.Sample sample = pp.QuerySample();
            if (sample == null)
            {
                projection.Dispose();
                return false;
            }

            int bitmap_width, bitmap_height;
            byte[] bitmap_data;
            switch (colorType)
            {
                case ColorType.COLOR: // color
                    if (sample.color != null)
                    {
                        bitmap_data = GetRGB32Pixels(sample.color, out bitmap_width, out bitmap_height);
                        SetBitmap(0, bitmap_width, bitmap_height, bitmap_data);

                        timer.Tick(sample.color.info.format.ToString().Substring(13) + " " + sample.color.info.width + "x" + sample.color.info.height);
                    }
                    break;
                case ColorType.DEPTH: // depth
                    if (sample.depth != null)
                    {
                        bitmap_data = GetRGB32Pixels(sample.depth, out bitmap_width, out bitmap_height);
                        SetBitmap(0, bitmap_width, bitmap_height, bitmap_data);
                        timer.Tick(sample.depth.info.format.ToString().Substring(13) + " " + sample.depth.info.width + "x" + sample.depth.info.height);
                    }
                    break;
                case ColorType.SEGMENTED: // segmented
                    if (segmented_image != null)
                    {
                        bitmap_data = GetRGB32Pixels(segmented_image, out bitmap_width, out bitmap_height);
                        SetBitmap(0, bitmap_width, bitmap_height, bitmap_data);
                        timer.Tick("RGB32 " + sample.color.info.width + "x" + sample.color.info.height);
                    }
                    break;
            }

            #region facial tracking part
             emotionData= pp.QueryEmotion();
             
            
            #endregion
            #region hand gesture related part
            if (handData != null)
            {
                handData.Update();
            }

            sample = pp.QueryHandSample();
            if (sample != null && sample.depth != null)
            {
                DisplayPicture(sample.depth, handData); //working
                //DisplayPicture(segmented_image, handData);
                if (handData != null)
                {
                    frameNumber = liveCamera ? frameCounter : pp.captureManager.QueryFrameIndex();

                    //DisplayJoints(handData);
                    #region display joints
                    PXCMHandData handOutput = handData; long timeStamp = 0;
                    //Iterate hands
                    nodes = new PXCMHandData.JointData[][] { new PXCMHandData.JointData[0x20], new PXCMHandData.JointData[0x20] };
                    numOfHands = handOutput.QueryNumberOfHands();
                    if (numOfHands == 0)
                    {
                        form.HandGestureTocar(posX, posY, posZ, 0);
                    }
                    for (int i = 0; i < numOfHands; i++)
                    {
                        //Get hand by time of appearence
                        //PXCMHandAnalysis.HandData handData = new PXCMHandAnalysis.HandData();

                        if (handOutput.QueryHandData(PXCMHandData.AccessOrderType.ACCESS_ORDER_BY_TIME, i, out ihandData) == pxcmStatus.PXCM_STATUS_NO_ERROR)
                        {
                            if (ihandData != null)
                            {
                                HandOpen[i] = ihandData.QueryOpenness();
                                var pt = ihandData.QueryMassCenterImage();
                                posX = pt.x;
                                posY = pt.y;
                                posZ = ihandData.QueryMassCenterWorld().y*1000;
                                form.Invoke((MethodInvoker)delegate
                                {
                                    form.Text = String.Format("X={0} Y={1} Z={2} OpenNess={3}", posX, posY, posZ,HandOpen[i]);
                                    form.HandGestureTocar(posX,posY,posZ,HandOpen[i]);
                                    // your UI update code here. e.g. this.Close();Label1.Text="something";
                                });
                               
                                //Iterate Joints
                                for (int j = 0; j < 0x20; j++)
                                {

                                   //ihandData.QueryTrackedJoint((PXCMHandData.JointType)j, out jointData);
                                   //nodes[i][j] = jointData;




                                } // end iterating over joints
                            }
                        }
                    } // end itrating over hands

                    #endregion
                    // DisplayGesture(handData, frameNumber);
                    #region DisplayGesture done locally
                    PXCMHandData handAnalysis = handData;
                    firedGesturesNumber = handAnalysis.QueryFiredGesturesNumber();
                    gestureStatusLeft = string.Empty;
                    gestureStatusRight = string.Empty;

                    for (int i = 0; i < firedGesturesNumber; i++)
                    {

                        if (handAnalysis.QueryFiredGestureData(i, out gestureData) == pxcmStatus.PXCM_STATUS_NO_ERROR)
                        {

                            if (handAnalysis.QueryHandDataById(gestureData.handId, out ihandData) != pxcmStatus.PXCM_STATUS_NO_ERROR)
                                continue;

                            PXCMHandData.BodySideType bodySideType = ihandData.QueryBodySide();
                            if (bodySideType == PXCMHandData.BodySideType.BODY_SIDE_LEFT)
                            {
                                gestureStatusLeft += "Left Hand Gesture: " + gestureData.name;
                            }
                            else if (bodySideType == PXCMHandData.BodySideType.BODY_SIDE_RIGHT)
                            {
                                gestureStatusRight += "Right Hand Gesture: " + gestureData.name;
                            }

                        }

                    }
                    if (gestureStatusLeft == String.Empty)
                    {
                        UpdateInfo("Frame " + frameNumber + ") " + gestureStatusRight + "\n", Color.SeaGreen);
                    }
                    else
                    {
                        UpdateInfo("Frame " + frameNumber + ") " + gestureStatusLeft + ", " + gestureStatusRight + "\n", Color.SeaGreen);
                    }
                    #endregion

                    //DisplayAlerts(handData, frameNumber);
                    #region DisplayAlert
                    bool isChanged = false;
                    string sAlert = "Alert: ";
                    int an = handAnalysis.QueryFiredAlertsNumber();
                    for (int i = 0; i < an; i++)
                    {

                        if (handAnalysis.QueryFiredAlertData(i, out alertData) != pxcmStatus.PXCM_STATUS_NO_ERROR)
                            continue;

                        //See PXCMHandAnalysis.AlertData.AlertType for all available alerts
                        switch (alertData.label)
                        {
                            case PXCMHandData.AlertType.ALERT_HAND_DETECTED:
                                {

                                    sAlert += "Hand Detected, ";
                                    isChanged = true;
                                    break;
                                }
                            case PXCMHandData.AlertType.ALERT_HAND_NOT_DETECTED:
                                {

                                    sAlert += "Hand Not Detected, ";
                                    isChanged = true;
                                    break;
                                }
                            case PXCMHandData.AlertType.ALERT_HAND_CALIBRATED:
                                {

                                    sAlert += "Hand Calibrated, ";
                                    isChanged = true;
                                    break;
                                }
                            case PXCMHandData.AlertType.ALERT_HAND_NOT_CALIBRATED:
                                {

                                    sAlert += "Hand Not Calibrated, ";
                                    isChanged = true;
                                    break;
                                }
                            case PXCMHandData.AlertType.ALERT_HAND_INSIDE_BORDERS:
                                {

                                    sAlert += "Hand Inside Border, ";
                                    isChanged = true;
                                    break;
                                }
                            case PXCMHandData.AlertType.ALERT_HAND_OUT_OF_BORDERS:
                                {

                                    sAlert += "Hand Out Of Borders, ";
                                    isChanged = true;
                                    break;
                                }
                        }
                    }
                    if (isChanged)
                    {
                        UpdateInfo("Frame " + frameNumber + ") " + sAlert + "\n", Color.RoyalBlue);
                    }

                    #endregion
                }

            }
            #endregion
            // form.UpdatePanel();
            segmented_image.Dispose();
            pp.ReleaseFrame();

            return true;


        }
    }
}
