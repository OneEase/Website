var mqtt = require('mqtt');

var client = mqtt.connect('mqtt://192.168.1.101');// chenge this to edison_local_ip. use ifconfig and
//look for wlan0 to knwo the ip address

// mqtt:// is important. Else code will not work. So if you are testing with mosquitto.org

// mqtt://test.mosquitto.org

var mraa = require('mraa')

var SPEED=1

////////////////// Remote Pins//////////////////

var fPin = new mraa.Gpio(6)

var bPin = new mraa.Gpio(5)

var rPin = new mraa.Gpio(3)

var lPin = new mraa.Gpio(4)

//////////////Set up Pins/////////////////////////

fPin.dir(mraa.DIR_OUT)

bPin.dir(mraa.DIR_OUT)

rPin.dir(mraa.DIR_OUT)

lPin.dir(mraa.DIR_OUT)

//////////////// Initialize///////////////////

fPin.write(0)

bPin.write(0)

rPin.write(0)

lPin.write(0)

/////////////////////////////////

client.subscribe('rupam/data/#')// change it as per your wish.

// # at the end is important. Else your code is not going to work

client.handleMessage=function(packet,cb) {

var payload = packet.payload.toString()

if (payload === 'FORWARD')

{

bPin.write(0);

fPin.write(SPEED)

}

if (payload === 'REVERSE')

{

fPin.write(0);

bPin.write(SPEED);

}

if (payload === 'RIGHT')

{

lPin.write(0);

rPin.write(1)

}

if (payload === 'LEFT')

{

rPin.write(0); lPin.write(1)

}

if (payload === 'STOP')

{

fPin.write(0)

rPin.write(0)

bPin.write(0)

lPin.write(0)

}

if (payload === 'NO')

{ rPin.write(0)

lPin.write(0)

}

console.log(payload) cb()

}