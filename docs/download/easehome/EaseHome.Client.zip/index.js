const argv = require('yargs').usage('Usage: $0')
                             .alias('v', 'verbose')
                             .count('verbose')
                             .describe('v', 'Sets the verbosity level')
                             .alias('c', 'config')
                             .nargs('c', 1)
                             .default('c', 'release')
                             .describe('c', 'Configuration to load')
                             .help('h')
                             .alias('h', 'help')
                             .epilog('copyright 2016')
                             .argv;

const Bot = require('./lib/bot.js');
const app = new Bot(argv.c, argv.v);
app.start();