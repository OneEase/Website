﻿namespace SmartHome.ChatBot.Adapter
{
    using System;
    using System.Linq;

    static class RegistryExtensions
    {
        public static ConnectionInfo GetFor(this IRegistry registry, String provider, String account)
        {
            return registry.GetAll().FirstOrDefault(m => 
                m.Providers.Any(n => 
                    n.Provider == provider && n.Account == account));
        }
    }
}