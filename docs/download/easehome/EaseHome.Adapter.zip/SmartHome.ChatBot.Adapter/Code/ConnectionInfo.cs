﻿namespace SmartHome.ChatBot.Adapter
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public sealed class ConnectionInfo
    {
        private readonly Dictionary<Guid, RequestInfo> _requests;

        public ConnectionInfo()
        {
            _requests = new Dictionary<Guid, RequestInfo>();
            Providers = new List<ProviderInfo>();
        }

        public String ShcSerial { get; set; }

        public String AuthCode { get; set; }

        public List<ProviderInfo> Providers { get; }

        public DateTime Created { get; set; }

        public DateTime Updated { get; set; }

        public ConnectionContext Context { get; set; }

        public RequestInfo GetRequest(Guid id)
        {
            var request = default(RequestInfo);
            ExpireRequests();
            _requests.TryGetValue(id, out request);
            return request;
        }

        public void LinkProvider(String provider, String account)
        {
            Providers.Add(new ProviderInfo { Account = account, Provider = provider });
        }

        public Task SendRequestAsync(Guid id, RequestInfo value, String evaluation)
        {
            ExpireRequests();
            value.Expires = DateTime.Now.AddMinutes(5);
            _requests[id] = value;
            return Context.Socket.SendAsync(id, evaluation);
        }

        private void ExpireRequests()
        {
            var expired = new List<Guid>();
            var current = DateTime.Now;

            foreach (var item in _requests)
            {
                if (item.Value.Expires.CompareTo(current) < 0)
                {
                    expired.Add(item.Key);
                }
            }

            foreach (var id in expired)
            {
                _requests.Remove(id);
            }
        }
    }
}