﻿namespace SmartHome.ChatBot.Adapter
{
    using Microsoft.Bot.Connector;
    using System;
    using System.Collections.Generic;

    public static class SystemMessageHandlers
    {
        private static readonly Dictionary<String, Func<Activity, Activity>> handlers = new Dictionary<String, Func<Activity, Activity>>
        {
            { ActivityTypes.DeleteUserData, activity => null },
            { ActivityTypes.ConversationUpdate, activity => null },
            { ActivityTypes.ContactRelationUpdate, activity => null },
            { ActivityTypes.Typing, activity => null },
            { ActivityTypes.Ping, activity => null },
        };

        public static Activity Handle(Activity message)
        {
            var handler = default(Func<Activity, Activity>);

            if (handlers.TryGetValue(message.Type, out handler))
            {
                return handler.Invoke(message);
            }

            return null;
        }
    }
}