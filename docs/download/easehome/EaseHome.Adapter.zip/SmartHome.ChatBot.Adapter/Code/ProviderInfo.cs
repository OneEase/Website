﻿namespace SmartHome.ChatBot.Adapter
{
    using System;

    public class ProviderInfo
    {
        public String Provider { get; set; }

        public String Account { get; set; }
    }
}