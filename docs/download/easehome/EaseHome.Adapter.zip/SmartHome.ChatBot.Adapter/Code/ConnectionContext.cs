﻿namespace SmartHome.ChatBot.Adapter
{
    using System;
    using System.Net.WebSockets;
    using System.Threading.Tasks;
    using System.Web.WebSockets;

    public class ConnectionContext
    {
        private readonly IScriptingHost _scripting;
        private readonly IRegistry _registry;
        private readonly AspNetWebSocketContext _context;
        private readonly Guid _id;

        public ConnectionContext(IScriptingHost scripting, IRegistry registry, AspNetWebSocketContext context)
        {
            _scripting = scripting;
            _registry = registry;
            _context = context;
            _id = Guid.NewGuid();
        }

        public WebSocket Socket
        {
            get { return _context.WebSocket; }
        }

        public async Task StartListening()
        {
            var ws = _context.WebSocket;

            _registry.Add(_id, this);

            await ws.SendAsync(new
            {
                type = "connected",
                value = _id.ToString()
            });

            await ws.DispatchAsync(_scripting);

            _registry.Remove(_id);
        }
    }
}