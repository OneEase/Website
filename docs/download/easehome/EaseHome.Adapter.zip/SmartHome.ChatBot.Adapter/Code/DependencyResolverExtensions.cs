﻿namespace SmartHome.ChatBot.Adapter
{
    using System.Web.Http.Dependencies;

    static class DependencyResolverExtensions
    {
        public static T GetService<T>(this IDependencyResolver resolver)
            where T : class
        {
            return resolver.GetService(typeof(T)) as T;
        }
    }
}