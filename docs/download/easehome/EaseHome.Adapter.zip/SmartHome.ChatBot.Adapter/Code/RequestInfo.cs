﻿namespace SmartHome.ChatBot.Adapter
{
    using Microsoft.Bot.Connector;
    using System;

    public class RequestInfo
    {
        public Uri ServiceUrl { get; set; }

        public ChannelAccount Bot { get; set; }

        public ChannelAccount User { get; set; }

        public ConversationAccount Conversation { get; set; }

        public DateTime Expires { get; set; }
    }
}