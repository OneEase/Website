﻿namespace SmartHome.ChatBot.Adapter
{
    using Mages.Core;
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Diagnostics;

    sealed class MagesScriptingHost : IScriptingHost
    {
        private readonly Engine _engine;
        private readonly IDictionary<String, Object> _scope;

        public MagesScriptingHost()
        {
            _scope = new Dictionary<String, Object>();
            _engine = new Engine(new Configuration
            {
                IsEngineExposed = false,
                IsEvalForbidden = true,
                IsThisAvailable = true,
                Scope = new ReadOnlyDictionary<String, Object>(_scope)
            });

            _engine.Globals.Clear();
            _engine.SetStatic(typeof(AdapterApi)).Scattered();
        }

        public IDictionary<String, Object> Scope
        {
            get { return _scope; }
        }

        public void Execute(String command)
        {
            try { _engine.Interpret(command); }
            catch (Exception ex) { Trace.TraceError(ex.Message); }
        }
    }
}