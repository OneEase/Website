﻿namespace SmartHome.ChatBot.Adapter
{
    using System;
    using System.Net.Http;
    using System.Threading.Tasks;

    public static class LuisClient
    {
        private static readonly String ApplicationId = WebConfigurationManager.AppSettings["LuisApplicationId"];
        private static readonly String SubscriptionId = WebConfigurationManager.AppSettings["LuisSubscriptionId"];

        public static async Task<String> EvaluateAsync(String input)
        {
            var query = Uri.EscapeDataString(input);

            using (var client = new HttpClient())
            {
                var uri = $"https://api.projectoxford.ai/luis/v1/application?id={ApplicationId}&subscription-key={SubscriptionId}&q={query}";
                var msg = await client.GetAsync(uri);

                if (msg.IsSuccessStatusCode)
                {
                    return await msg.Content.ReadAsStringAsync();
                }
            }

            return null;
        }
    }
}
