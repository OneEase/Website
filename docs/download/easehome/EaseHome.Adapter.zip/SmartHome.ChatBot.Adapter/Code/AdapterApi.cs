﻿namespace SmartHome.ChatBot.Adapter
{
    using Microsoft.Bot.Connector;
    using System;
    using System.Web.Http;
    using System.Web.Http.Dependencies;

    static class AdapterApi
    {
        private static readonly IDependencyResolver Resolver = GlobalConfiguration.Configuration.DependencyResolver;

        public static void Register(String id, String shcSerial)
        {
            var connection = GetConnectionOf(id);
            connection.Updated = DateTime.Now;
            connection.ShcSerial = shcSerial;
        }

        public static void Update(String id, String authCode)
        {
            var connection = GetConnectionOf(id);
            connection.AuthCode = authCode;
        }

        public static void Link(String id, String provider, String account)
        {
            var connection = GetConnectionOf(id);
            connection.LinkProvider(provider, account);
        }

        public static void Answer(String id, String request, String answer)
        {
            var connection = GetConnectionOf(id);
            var reply = CreateReplyFor(connection, request);
            reply.Invoke(answer);
        }

        private static Action<String> CreateReplyFor(ConnectionInfo connection, String id)
        {
            var info = connection.GetRequest(Guid.Parse(id));
            var connector = new ConnectorClient(info.ServiceUrl);
            var message = Activity.CreateMessageActivity();
            message.Type = ActivityTypes.Message;
            message.From = info.Bot;
            message.Recipient = info.User;
            message.Conversation = info.Conversation;

            return text =>
            {
                message.Text = text;
                connector.Conversations.SendToConversation((Activity)message);
            };
        }

        private static ConnectionInfo GetConnectionOf(String id)
        {
            var registry = Resolver.GetService<IRegistry>();
            return registry.Get(Guid.Parse(id));
        }
    }
}