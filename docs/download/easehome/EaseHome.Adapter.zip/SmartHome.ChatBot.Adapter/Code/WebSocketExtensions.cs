﻿namespace SmartHome.ChatBot.Adapter
{
    using Newtonsoft.Json;
    using System;
    using System.IO;
    using System.Net.WebSockets;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;

    static class WebSocketExtensions
    {
        public static Task SendAsync(this WebSocket ws, Object value)
        {
            var text = JsonConvert.SerializeObject(value);
            return ws.SendAsync(text);
        }

        public static Task SendAsync(this WebSocket ws, String text)
        {
            var bytes = Encoding.UTF8.GetBytes(text);
            var buffer = new ArraySegment<Byte>(bytes);
            return ws.SendAsync(buffer, WebSocketMessageType.Text, true, CancellationToken.None);
        }

        public static Task SendAsync(this WebSocket ws, Guid id, String question)
        {
            return ws.SendAsync(new
            {
                type = "question",
                value = new
                {
                    id = id.ToString(),
                    evaluation = JsonConvert.DeserializeObject(question)
                },
            });
        }

        public static Task SendAsync(this WebSocket ws, String provider, String account)
        {
            return ws.SendAsync(new
            {
                type = "link",
                value = new
                {
                    provider = provider,
                    account = account
                },
            });
        }

        public static async Task DispatchAsync(this WebSocket ws, IScriptingHost scripting)
        {
            var buffer = new Byte[1024];
            var inputSegment = new ArraySegment<Byte>(buffer);
            var ms = new MemoryStream();
            var result = default(WebSocketReceiveResult);

            do
            {
                try
                {
                    result = await ws.ReceiveAsync(inputSegment, CancellationToken.None);
                }
                catch (WebSocketException)
                {
                    break;
                }

                ms.Write(buffer, 0, result.Count);

                if (result.MessageType == WebSocketMessageType.Text && result.EndOfMessage)
                {
                    var raw = ms.ToArray();
                    var message = Encoding.UTF8.GetString(raw);
                    scripting.Execute(message);
                    ms.Position = 0;
                    ms.SetLength(0);
                }
            }
            while (ws.State == WebSocketState.Open);
        }
    }
}