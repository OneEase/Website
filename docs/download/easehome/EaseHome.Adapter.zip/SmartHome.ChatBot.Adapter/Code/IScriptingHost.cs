﻿namespace SmartHome.ChatBot.Adapter
{
    using System;
    using System.Collections.Generic;

    public interface IScriptingHost
    {
        IDictionary<String, Object> Scope { get; }

        void Execute(String command);
    }
}
