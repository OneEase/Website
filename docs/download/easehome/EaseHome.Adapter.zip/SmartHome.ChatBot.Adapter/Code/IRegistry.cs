﻿namespace SmartHome.ChatBot.Adapter
{
    using System;
    using System.Collections.Generic;

    public interface IRegistry
    {
        void Add(Guid id, ConnectionContext context);

        void Remove(Guid id);

        ConnectionInfo Get(Guid id);

        IEnumerable<ConnectionInfo> GetAll();
    }
}
