﻿namespace SmartHome.ChatBot.Adapter
{
    using System;
    using System.Collections.Generic;

    sealed class MemoryRegistry : IRegistry
    {
        private readonly Dictionary<Guid, ConnectionInfo> _connections;

        public MemoryRegistry()
        {
            _connections = new Dictionary<Guid, ConnectionInfo>();
        }

        public void Add(Guid id, ConnectionContext context)
        {
            _connections[id] = new ConnectionInfo
            {
                Context = context,
                Created = DateTime.Now,
                Updated = DateTime.Now
            };
        }

        public ConnectionInfo Get(Guid id)
        {
            var value = default(ConnectionInfo);
            _connections.TryGetValue(id, out value);
            return value;
        }

        public IEnumerable<ConnectionInfo> GetAll()
        {
            return _connections.Values;
        }

        public void Remove(Guid id)
        {
            _connections.Remove(id);
        }
    }
}