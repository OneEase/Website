namespace SmartHome.ChatBot.Adapter
{
    using Microsoft.Practices.Unity;
    using System.Web.Http;
    using Unity.WebApi;

    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();
            container.RegisterInstance<IRegistry>(new MemoryRegistry());
            container.RegisterInstance<IScriptingHost>(new MagesScriptingHost());
            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }
    }
}