﻿namespace SmartHome.ChatBot.Adapter
{
    using Microsoft.Bot.Connector;
    using System;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;

    [BotAuthentication]
    public class MessagesController : ApiController
    {
        private readonly IRegistry _registry;

        public MessagesController(IRegistry registry)
        {
            _registry = registry;
        }
        
        public async Task<HttpResponseMessage> Post([FromBody]Activity activity)
        {
            if (activity.Type == ActivityTypes.Message)
            {
                var serviceUrl = new Uri(activity.ServiceUrl);
                var connector = new ConnectorClient(serviceUrl);
                var connection = _registry.GetFor(activity.ChannelId, activity.From.Id);

                if (connection != null)
                {
                    await AskQuestionAsync(activity, serviceUrl, connection);
                }
                else
                {
                    await TryRegisterAsync(activity, connector);
                }
            }
            else
            {
                SystemMessageHandlers.Handle(activity);
            }

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        private static async Task AskQuestionAsync(Activity activity, Uri serviceUrl, ConnectionInfo connection)
        {
            var message = activity.Text ?? String.Empty;
            var id = Guid.NewGuid();
            var evaluation = await LuisClient.EvaluateAsync(message);
            var request = new RequestInfo
            {
                User = activity.From,
                Bot = activity.Recipient,
                Conversation = activity.Conversation,
                ServiceUrl = serviceUrl
            };

            await connection.SendRequestAsync(id, request, evaluation);
        }

        private async Task TryRegisterAsync(Activity activity, ConnectorClient connector)
        {
            var reply = default(Activity);
            var message = activity.Text ?? String.Empty;
            var connection = _registry.GetAll().FirstOrDefault(m => m.AuthCode == message);

            if (connection != null)
            {
                connection.LinkProvider(activity.ChannelId, activity.From.Id);
                await connection.Context.Socket.SendAsync(activity.ChannelId, activity.From.Id);
                reply = activity.CreateReply($"Successfully registered the account for the SHC {connection.ShcSerial}.");
            }
            else
            {
                reply = activity.CreateReply($"Invalid authentication code (sent from {activity.ChannelId} with account {activity.From.Id}).");
            }

            await connector.Conversations.ReplyToActivityAsync(reply);
        }
    }
}