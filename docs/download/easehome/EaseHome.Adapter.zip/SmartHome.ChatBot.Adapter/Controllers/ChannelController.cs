﻿namespace SmartHome.ChatBot.Adapter.Controllers
{
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web;
    using System.Web.Http;
    using System.Web.WebSockets;

    public class ChannelController : ApiController
    {
        private readonly IRegistry _registry;
        private readonly IScriptingHost _scripting;

        public ChannelController(IScriptingHost scripting, IRegistry registry)
        {
            _scripting = scripting;
            _registry = registry;
        }

        public HttpResponseMessage Get()
        {
            HttpContext.Current.AcceptWebSocketRequest(CreateContextAndHandleConnection);
            return Request.CreateResponse(HttpStatusCode.SwitchingProtocols);
        }

        private Task CreateContextAndHandleConnection(AspNetWebSocketContext context)
        {
            var connection = new ConnectionContext(_scripting, _registry, context);
            return connection.StartListening();
        }
    }
}