#pragma once
#include <WiFi.h>

SlDateTime_t getCurrentTime();

void setCurrentTime();
