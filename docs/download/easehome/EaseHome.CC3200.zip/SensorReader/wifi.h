#pragma once

void connectWifi(char* ssid, char* password);