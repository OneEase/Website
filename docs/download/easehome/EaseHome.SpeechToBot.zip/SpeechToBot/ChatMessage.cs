﻿namespace SpeechToBot
{
    using System;
    using System.Windows.Media;

    public sealed class ChatMessage
    {
        public String Text
        {
            get;
            set;
        }

        public DateTime Received
        {
            get;
            set;
        }

        public String Sender
        {
            get;
            set;
        }

        public SolidColorBrush Color
        {
            get;
            set;
        }
    }
}
