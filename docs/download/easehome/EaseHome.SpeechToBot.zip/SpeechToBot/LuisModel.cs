﻿namespace SpeechToBot
{
    using System;

    sealed class LuisModel
    {
        public String Query { get; set; }
    }
}
