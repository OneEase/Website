﻿namespace SpeechToBot
{
    using System;

    sealed class MessageEvent : EventArgs
    {
        public MessageEvent(String text, DateTime? created, String sender)
        {
            Text = text;
            Created = created ?? DateTime.Now;
            Sender = sender;
        }

        public String Text { get; }

        public DateTime Created { get; }

        public String Sender { get; }
    }
}
