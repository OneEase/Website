﻿namespace SpeechToBot
{
    using Microsoft.Bot.Connector;
    using Microsoft.Bot.Connector.DirectLine;
    using Microsoft.Bot.Connector.DirectLine.Models;
    using System;
    using System.Configuration;
    using System.Threading;
    using System.Threading.Tasks;

    sealed class MessageChannel : IDisposable
    {
        private static readonly String Secret = ConfigurationManager.AppSettings["DirectLineSecret"];
        private static readonly String EndPoint = ConfigurationManager.AppSettings["SmartBotEndpoint"];
        private static readonly Uri DirectLine = new Uri("https://directline.botframework.com");

        private readonly Conversation _conversation;
        private readonly DirectLineClient _client;

        public event EventHandler<MessageEvent> Received;

        public MessageChannel()
        {
            var credentials = new DirectLineClientCredentials(Secret, EndPoint);
            _client = new DirectLineClient(DirectLine, credentials);
            _conversation = _client.Conversations.NewConversation();
        }

        public Task SendAsync(String content)
        {
            var message = new Message(text: content);
            return _client.Conversations.PostMessageAsync(_conversation.ConversationId, message);
        }

        public async Task ReceiveAsync(CancellationToken cancellationToken)
        {
            var watermark = default(String);

            while (!cancellationToken.IsCancellationRequested)
            {
                var messages = await _client.Conversations.GetMessagesAsync(_conversation.ConversationId, watermark, cancellationToken);

                foreach (var message in messages.Messages)
                {
                    Received?.Invoke(this, new MessageEvent(message.Text, message.Created, message.FromProperty));
                }

                watermark = messages.Watermark;
            }
        }

        public void Dispose()
        {
            _client.Dispose();
        }
    }
}
