﻿namespace SpeechToBot
{
    using System;
    using System.Windows.Input;

    sealed class RelayCommand : ICommand
    {
        private readonly Action _command;

        public event EventHandler CanExecuteChanged;

        public RelayCommand(Action command)
        {
            _command = command;
        }

        public Boolean CanExecute(Object parameter)
        {
            return true;
        }

        public void Execute(Object parameter)
        {
            _command.Invoke();
        }
    }
}