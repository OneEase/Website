﻿namespace SpeechToBot
{
    using System;
    using System.Speech.Synthesis;

    sealed class SpeechChannel : IDisposable
    {
        private readonly SpeechSynthesizer _synthesizer;

        public SpeechChannel()
        {
            _synthesizer = new SpeechSynthesizer();
        }

        public void Dispose()
        {
            _synthesizer.Dispose();
        }

        public void Say(String message)
        {
            _synthesizer.SpeakAsync(message);
        }
    }
}
