﻿namespace SpeechToBot
{
    using System;
    using System.ComponentModel;
    using System.Windows;

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Closing += MainWindow_Closing;
        }

        private void MainWindow_Closing(Object sender, CancelEventArgs e)
        {
            (DataContext as IDisposable)?.Dispose();
        }
    }
}
