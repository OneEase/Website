﻿namespace SpeechToBot
{
    using Microsoft.ProjectOxford.SpeechRecognition;
    using System;
    using System.Configuration;
    using System.Diagnostics;
    using System.Linq;

    sealed class VoiceChannel : IDisposable
    {
        private static String SpeechLocale = ConfigurationManager.AppSettings["SpeechLocale"];
        private static String LuisApplicationId = ConfigurationManager.AppSettings["LuisApplicationId"];
        private static String LuisSubscriptionId = ConfigurationManager.AppSettings["LuisSubscriptionId"];
        private static String BingPrimaryKey = ConfigurationManager.AppSettings["BingPrimaryKey"];
        private static String BingSecondaryKey = ConfigurationManager.AppSettings["BingSecondaryKey"];

        private readonly MicrophoneRecognitionClientWithIntent _mic;
        private Boolean _recording;

        public event EventHandler<IntentEvent> ReceivedIntent
        {
            add { _mic.OnIntent += (sender, ev) => value.Invoke(sender, new IntentEvent(ev.Payload)); }
            remove { _mic.OnIntent -= (sender, ev) => value.Invoke(sender, new IntentEvent(ev.Payload)); }
        }

        public VoiceChannel()
        {
            _recording = false;
            _mic = SpeechRecognitionServiceFactory.CreateMicrophoneClientWithIntent(
                SpeechLocale,
                BingPrimaryKey,
                BingSecondaryKey,
                LuisApplicationId,
                LuisSubscriptionId);
            _mic.OnResponseReceived += _mic_OnResponseReceived;
            _mic.OnMicrophoneStatus += _mic_OnMicrophoneStatus;
        }

        public Boolean IsRecording
        {
            get { return _recording; }
        }

        public void ToggleRecording()
        {
            if (_recording)
            {
                _mic.EndMicAndRecognition();
            }
            else
            {
                _mic.StartMicAndRecognition();
            }

            _recording = !_recording;
        }

        private void _mic_OnMicrophoneStatus(Object sender, MicrophoneEventArgs e)
        {
            Debug.WriteLine(e.Recording ? "Recording ..." : "Stopped recording!");
        }

        private void _mic_OnResponseReceived(Object sender, SpeechResponseEventArgs e)
        {
            foreach (var phrase in e.PhraseResponse?.Results ?? Enumerable.Empty<RecognizedPhrase>())
            {
                Debug.WriteLine(phrase.DisplayText);
            }
        }

        public void Dispose()
        {
            _mic.Dispose();
        }
    }
}
