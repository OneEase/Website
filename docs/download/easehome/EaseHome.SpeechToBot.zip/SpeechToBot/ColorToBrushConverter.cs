﻿namespace SpeechToBot
{
    using System;
    using System.Globalization;
    using System.Windows.Data;
    using System.Windows.Media;

    sealed class ColorToBrushConverter : IValueConverter
    {
        public Object Convert(Object value, Type targetType, Object parameter, CultureInfo culture)
        {
            return new SolidColorBrush((Color)value);
        }

        public Object ConvertBack(Object value, Type targetType, Object parameter, CultureInfo culture)
        {
            return ((SolidColorBrush)value).Color;
        }
    }
}
