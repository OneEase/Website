﻿namespace SpeechToBot
{
    using Newtonsoft.Json;
    using System;

    sealed class IntentEvent : EventArgs
    {
        public IntentEvent(String payload)
        {
            Payload = payload;
        }

        public String Payload { get; }

        public String Query
        {
            get { return GetMessage(Payload); }
        }

        private static String GetMessage(String payload)
        {
            var model = JsonConvert.DeserializeObject<LuisModel>(payload);
            return model?.Query;
        }
    }
}
