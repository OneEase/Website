﻿namespace SpeechToBot
{
    using System;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Runtime.CompilerServices;
    using System.Threading;
    using System.Windows.Input;
    using System.Windows.Media;

    public sealed class MainViewModel : INotifyPropertyChanged, IDisposable
    {
        private readonly MessageChannel _message;
        private readonly VoiceChannel _voice;
        private readonly SpeechChannel _speech;
        private readonly ICommand _toggle;
        private readonly CancellationTokenSource _cts;
        private ObservableCollection<ChatMessage> _messages;

        public event PropertyChangedEventHandler PropertyChanged;

        public MainViewModel()
        {
            _message = new MessageChannel();
            _voice = new VoiceChannel();
            _speech = new SpeechChannel();
            _toggle = new RelayCommand(ToggleClick);
            _cts = new CancellationTokenSource();
            _messages = new ObservableCollection<ChatMessage>();
            _voice.ReceivedIntent += ReceivedIntent;
            _message.Received += MessageReceived;
            var task = _message.ReceiveAsync(_cts.Token);
        }

        public ObservableCollection<ChatMessage> Messages
        {
            get { return _messages; }
        }

        public ICommand Toggle
        {
            get { return _toggle; }
        }

        public Boolean IsRecording
        {
            get { return _voice.IsRecording; }
        }

        private void MessageReceived(Object sender, MessageEvent e)
        {
            var fromBot = e.Sender.Equals("smarthomebot", StringComparison.InvariantCultureIgnoreCase);
            _messages.Add(new ChatMessage
            {
                Sender = fromBot ? "SmartHome" : "You",
                Text = e.Text,
                Color = new SolidColorBrush(fromBot ? Colors.Purple : Colors.SteelBlue),
                Received = e.Created
            });

            if (fromBot)
            {
                _speech.Say(e.Text);
            }
        }

        private void ReceivedIntent(Object sender, IntentEvent e)
        {
            _message.SendAsync(e.Query);
        }

        private void ToggleClick()
        {
            _voice.ToggleRecording();
            RaisePropertyChanged("IsRecording");
        }

        private void RaisePropertyChanged([CallerMemberName] String propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public void Dispose()
        {
            _cts.Cancel();
            _voice.Dispose();
            _message.Dispose();
            _speech.Dispose();
        }
    }
}
