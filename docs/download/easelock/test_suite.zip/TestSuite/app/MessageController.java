package app;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.Arrays;

public class MessageController {
    private MessageTransmitter transmitter;
    private MessageReceiver receiver;
    private boolean isAuthenticated;
    private byte[] password;

    public MessageController(InputStream in, OutputStream out, byte[] initialPassword) {
        this.transmitter = new MessageTransmitter(in, out);
        this.receiver = new MessageReceiver(in, out);
        this.isAuthenticated = false;
        this.password = initialPassword;
    }

    public void sendDoorCommand(byte[] command) {
        if (isAuthenticated) {
			System.out.println("controller: auth, send door cmd");
            sendDoorCommandInternal(command);
        } else {
			System.out.println("controller: not auth, auth and send door cmd");
            authenticateAndExecute(() -> sendDoorCommandInternal(command));
        }
    }

    public void sendChangePasswordRequest(byte[] newPassword) {
        if (isAuthenticated) {
            sendChangePasswordRequestInternal(newPassword);
        } else {
            authenticateAndExecute(() -> sendChangePasswordRequestInternal(newPassword));
        }
    }

    private void authenticateAndExecute(Runnable onAuthenticated) {
        sendAuthRequest(() -> {
            handleAuthResponse(() -> {
                isAuthenticated = true;
                onAuthenticated.run();
            });
        });
    }

    private void sendAuthRequest(Runnable onResponseReceived) {
		System.out.println("controller: send auth request");
        // 8 packets
        //byte[] authPayload = "auth_request00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000".getBytes(); // Empty auth message payload
        // 5 packets
        //byte[] authPayload = "auth_request000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000".getBytes(); // Empty auth message payload
        // 3 packets
        //byte[] authPayload = "123456789123456789123456789123456789abcdefghijklmnopqrstuvwxyz".getBytes(); // Empty auth message payload

        // 2 packets
        //byte[] authPayload = "auth_request::dummy_payload123456789123456789".getBytes(); // Empty auth message payload
        // 1 packet
        byte[] authPayload = "dummy_auth_request".getBytes(); // Empty auth message payload
        Message authMessage = Message.createAuthMessage(authPayload);
        transmitter.sendMessage(authMessage);
		System.out.println("controller: read auth response");
        onResponseReceived.run();
    }

    private void sendSyncTimestampRequest(Runnable onResponseReceived) {
        long currentTimestamp = System.currentTimeMillis() / 1000;
        Message syncTimestampMessage = Message.createSyncTimestampMessage(currentTimestamp);
        transmitter.sendMessage(syncTimestampMessage);
        onResponseReceived.run();
    }

    private void sendChallengeResponse(byte[] challenge, Runnable onResponseReceived) {
        byte[] passwordHash = hashPassword(challenge, password);
        Message challengeResponseMessage = Message.createChallengeResponseMessage(challenge, passwordHash);
        transmitter.sendMessage(challengeResponseMessage);
        onResponseReceived.run();
    }

    private void sendDoorCommandInternal(byte[] command) {
        Message doorCommandMessage = Message.createDoorCommandMessage(command);
        transmitter.sendMessage(doorCommandMessage);
        handleResponse();
    }

    private void sendChangePasswordRequestInternal(byte[] newPassword) {
        Message changePasswordMessage = Message.createChangePasswordMessage(newPassword);
        transmitter.sendMessage(changePasswordMessage);
        handleResponse(newPassword);
    }

    private void handleAuthResponse(Runnable onAuthenticated) {
        Message response = handleResponse();
        System.out.println("handleAuthResponse");
        if (response.msgType == Message.MSG_TYPE_SYNC_TIMESTAMP) {
            sendSyncTimestampRequest(() -> {
                handleResponse();
                sendAuthRequest(onAuthenticated);
            });
        } else if (response.msgType == Message.MSG_TYPE_CHALLENGE_RESPONSE) {
            System.out.println("sending challenge response");
            byte[] challenge = Arrays.copyOfRange(response.payload, 0, response.payload.length);
            sendChallengeResponse(challenge, onAuthenticated);
        }
    }

    private Message handleResponse() {
        return handleResponse(null);
    }

    private Message handleResponse(byte[] newPassword) {
        try {
            Message response = receiver.receiveMessage();
            if (response.msgType == Message.MSG_TYPE_NOTIFY) {
                handleNotify(response);
            }
            if (response.msgType == Message.MSG_TYPE_CHANGE_PASSWORD && newPassword != null) {
                password = newPassword;
            }
            return response;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void handleNotify(Message notifyMessage) {
        // Handle the notify message
        short packetNumber = (short) ((notifyMessage.payload[0] << 8) | (notifyMessage.payload[1] & 0xFF));
        byte messageType = notifyMessage.payload[2];
        short result = (short) ((notifyMessage.payload[3] << 8) | (notifyMessage.payload[4] & 0xFF));
        byte[] desc = Arrays.copyOfRange(notifyMessage.payload, 5, notifyMessage.payload.length);

        // TODO: Process the notification based on the messageType and result
        
    }

	private byte[] hashPassword(byte[] challenge, byte[] password) {
		int length = Math.max(challenge.length, password.length);
		byte[] hashed = new byte[length];

		for (int i = 0; i < length; i++) {
			byte challengeByte = (i < challenge.length) ? challenge[i] : 0;
			byte passwordByte = (i < password.length) ? password[i] : 0;
			hashed[i] = (byte) (challengeByte ^ passwordByte);
		}

		return hashed;
	}

}

