package app;

import java.io.*;
import java.net.*;

public class BluetoothCommunicationTest {

    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 8080);
            OutputStream out = socket.getOutputStream();
            InputStream in = socket.getInputStream();

            MessageController controller = new MessageController(in, out, "default_password".getBytes());

            // Test sending door command
			System.out.println("controller send door command");
            controller.sendDoorCommand("OPEN".getBytes());

            // Test changing password
			System.out.println("controller send change password command");
            controller.sendChangePasswordRequest("new_password".getBytes());

            // TODO: Add more tests in the following

            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
}
