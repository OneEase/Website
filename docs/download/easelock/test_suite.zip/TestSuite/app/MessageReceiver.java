package app;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.*;

public class MessageReceiver {
    private InputStream mmIn;
    private OutputStream mmOut;
    private List<byte[]> receivedPackets;
    private int expectedSequenceNumber;
    private short expectedPacketNumber;

    public MessageReceiver(InputStream in, OutputStream out) {
        this.mmIn = in;
        this.mmOut = out;
        this.receivedPackets = new ArrayList<>();
        this.expectedSequenceNumber = 0x81;
        this.expectedPacketNumber = -1;
    }

    public Message receiveMessage() throws IOException {
		short pn = 0;
        while (true) {
            byte[] packet = new byte[32]; // MTU size is 32 bytes
            int bytesRead = mmIn.read(packet);

            if (bytesRead > 0) {
                short packetNumber = (short) ((packet[0] << 8) | (packet[1] & 0xFF));
                byte sequenceNumber = packet[2];
                short checksum = (short) ((packet[3] << 8) | (packet[4] & 0xFF));
                byte msgType = packet[5];
                short msgSize = (short) ((packet[6] << 8) | (packet[7] & 0xFF));
                int len = Math.min(msgSize, 24);
                byte[] payload = Arrays.copyOfRange(packet, 8, len + 8);

                // Check sequence number and checksum
				if ((sequenceNumber & 0x80) == 0x80) {  // First packet
					expectedSequenceNumber = sequenceNumber & 0x7F;
                    receivedPackets.clear();
                    receivedPackets.add(packet);
					expectedPacketNumber = packetNumber;
                    System.out.println("receive first packet");
                    Message.log(packet);
					// Send ACK for successful packet
                    sendAck(packetNumber, sequenceNumber, true);
					// If this is the last packet (sequenceNumber = 1)
					if (expectedSequenceNumber == 1) {
						return Message.assemblePacket(receivedPackets.toArray(new byte[0][]), 32);
					}
                    expectedSequenceNumber--;
				} else if (sequenceNumber == expectedSequenceNumber && packetNumber == expectedPacketNumber && checksum == Message.crc16(payload)) { // Subsequent packet
                    System.out.println("receive subsequent packet");
                    System.out.println(String.format("seq: 0x%x,pn:0x%x", sequenceNumber, packetNumber));
                    receivedPackets.add(packet);

                    Message.log(packet);
                    // Send ACK for successful packet
                    sendAck(packetNumber, sequenceNumber, true);

                    // If this is the last packet (sequenceNumber = 1)
                    if (expectedSequenceNumber == 1) {
                        return Message.assemblePacket(receivedPackets.toArray(new byte[0][]), 32);
                    }
                    expectedSequenceNumber--;
                } else {
                    System.out.println("receiver: error packet");
                    System.out.println(String.format("expected seq: 0x%x,exepected pn:0x%x", expectedSequenceNumber, expectedPacketNumber));
                    System.out.println(String.format("seq test: %x", (sequenceNumber == expectedSequenceNumber)?1:0));
                    System.out.println(String.format("pkt test: %x", (packetNumber == expectedPacketNumber)?1:0));
                    System.out.println(String.format("checksum  test: %x", (checksum == Message.crc16(payload))?1:0));
                    System.out.println(String.format("expected checksum: 0x%x,real checksum:0x%x", checksum, Message.crc16(payload)));
                    Message.log(packet);
                    // Send ACK for successful packet
                    // Send ACK for erroneous packet
                    sendAck(packetNumber, sequenceNumber, false);
					// The sender should retransmit and it will update the HashMap
                }
            }
        }
    }

    private void sendAck(short packetNumber, byte sequenceNumber, boolean status) throws IOException {
        Message ackMessage = Message.createAckMessage(packetNumber, sequenceNumber, status);
        byte[][] msgPackets = Message.fragmentPacket(ackMessage, 32); // 32 is the MTU size
        System.out.println(String.format("sending ack packet. seq: 0x%x,pn:0x%x, status:%d", sequenceNumber, packetNumber, status?1:0));
        Message.log(msgPackets[0]);
        mmOut.write(msgPackets[0]);
        mmOut.flush();
    }
}

