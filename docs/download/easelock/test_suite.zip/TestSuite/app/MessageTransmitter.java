package app;
import java.io.*;
import app.Message;
import java.util.Timer;
import java.util.TimerTask;
import java.util.HashMap;
import java.util.Map;

public class MessageTransmitter {
    // Timeout value for packet retransmission (100ms)
    private static final int TIMEOUT_VALUE = 100; 
    // Maximum number of retransmissions (3)
    private static final int MAX_RETRANSMISSIONS = 3;

    // Map to store packets with their sequence numbers
    private Map<Integer, byte[]> messageMap;
    // Next sequence number to be sent
    private int nextSequenceNumber;
    // Current message being transmitted
    private Message msg;
    // Fragmented packets of the current message
    private byte[][] msgPackets;

    // Input and output streams for Bluetooth communication
    private InputStream mmIn;
    private OutputStream mmOut;

    // Timer for packet retransmission
    private Timer timer;

    public MessageTransmitter(InputStream in, OutputStream out) {
        messageMap = new HashMap<>();
        nextSequenceNumber = 0;
        mmIn = in;
        mmOut = out;
    }

    /**
     * Send a message over Bluetooth
     * @param message the message to be sent
     */
    public void sendMessage(Message message) {
        try {
            msg = message;
            // Fragment the message into packets
            msgPackets = Message.fragmentPacket(message, 32); // 32 is the MTU size
            for (byte[] packet : msgPackets) {
                int sequenceNumber = packet[2];
                messageMap.put(sequenceNumber, packet);
            }
            int seq = msgPackets[0][2] & 0x7F;
            nextSequenceNumber = seq - 1;

            // Send the first packet
            sendPacket(msgPackets[0][2], msgPackets[0]);
        }catch(Exception e) {
            e.printStackTrace();
            System.out.print(e.getMessage());
            return;
        }
    }

    /**
     * Send a packet over Bluetooth
     * @param sequenceNumber the sequence number of the packet
     * @param packet the packet to be sent
     */
    private void sendPacket(int sequenceNumber, byte[] packet) {
        try {
            System.out.println(String.format("sending packet seq 0x%x", (byte)sequenceNumber));
            Message.log(packet);
            // Send the packet over Bluetooth
            mmOut.write(packet);
            mmOut.flush();
            // Start a timer for packet retransmission
            startTimer(sequenceNumber, TIMEOUT_VALUE);
            // Read ACK from receiver
            readAckPacket(sequenceNumber);
        }catch(Exception e) {
            return;
        }
    }

    /**
     * Start a timer for packet retransmission
     * @param sequenceNumber the sequence number of the packet
     * @param timeoutValue the timeout value for retransmission
     */
    private void startTimer(int sequenceNumber, int timeoutValue) {
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handlePacketLoss(sequenceNumber);
            }
        }, timeoutValue);
    }

    /**
     * Handle packet loss by retransmitting the packet
     * @param sequenceNumber the sequence number of the packet
     */
    private void handlePacketLoss(int sequenceNumber) {
        System.out.println(String.format("timeout: resend seq 0x%x", (byte)sequenceNumber));
        byte[] packet = messageMap.get(sequenceNumber);
        if (packet!= null) {
            // Retransmit the packet
            sendPacket(sequenceNumber, packet);
        } else {
            // Unknown error
        }
    }

    /**
     * Resend the entire message
     */
    private void resendMessage() {
        System.out.println("sender: resend all packets");
        int retransmissionCount = msg.getRetransmissionCount();
        if (retransmissionCount < MAX_RETRANSMISSIONS) {
            msg.setRetransmissionCount(retransmissionCount + 1);
            // Resend all packets
            int seq = msgPackets[0][2] & 0x7F;
            nextSequenceNumber = seq - 1;
            sendPacket(msgPackets[0][2], msgPackets[0]);
        } else {
            // Report error: packet lost after max retransmissions
            return;
        }
    }

    /**
     * Read an ACK packet from the input stream
     * @param sequenceNumber the sequence number of the packet
     */
    private void readAckPacket(int sequenceNumber) {
        try {
            byte[] ackBuffer = new byte[32]; // ACK packet is 12 bytes
            System.out.println("read ack packet");    
            int bytesRead = mmIn.read(ackBuffer);
			if (bytesRead < 0) {
				System.out.println("Error reading ACK packet");
			} else if (bytesRead < ackBuffer.length) {
				System.out.println("Only read " + bytesRead + " bytes of the ACK packet");
			} else {
				System.out.println("Read entire ACK packet");
				Message.log(ackBuffer);
			}
            //Message.log(ackBuffer);
			/* 
                Check that: 
                1. sequence number is the same for sender and receiver, otherwise report error.
                    ackBuffer[10] is the sequence number in ack message: 8(header size) + 2(payload offset)
			    2. message type is ACK. 0x06 is ACK message type
                3. ack message size is 12
            */
            if (ackBuffer[10] == (byte)sequenceNumber && ackBuffer[5] == (byte)0x06) { 
				System.out.println("ack ok");	
                receiveAckPacket(sequenceNumber, 1);
            } else {
				System.out.println("ack fail");	
                System.out.println(String.format("recv act packet for seq 0x%x", (byte)sequenceNumber));
                System.out.println(String.format("1: %d",bytesRead));
                System.out.println(String.format("2: %d",(ackBuffer[10] == (byte)sequenceNumber)?1:0));
                System.out.println(String.format("2:0x%x", ackBuffer[10]));
                System.out.println(String.format("3: %d",(ackBuffer[5] == (byte)0x06)?1:0));
                System.out.println(String.format("3:0x%x", ackBuffer[5]));
                receiveAckPacket(sequenceNumber, 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Receive an ACK packet and handle it accordingly
     * @param sequenceNumber the sequence number of the packet
     * @param status the status of the packet (1 = acknowledged, 0 = error)
     */
    public void receiveAckPacket(int sequenceNumber, int status) {
        byte[] packet = messageMap.get(sequenceNumber);
        if (packet!= null) {
            if (status == 1) {
                // Packet acknowledged, send next packet
                timer.cancel(); // cancel the timer
                int next = nextSequenceNumber;
                if (next == 0) {
                    // All packets are sent
                    return;
                }
                System.out.println(String.format("previous sent seq: 0x%x, sending seq: 0x%x", (byte)sequenceNumber, next));
                nextSequenceNumber--;
                sendPacket(next, messageMap.get(next));
            } else {
                timer.cancel(); // cancel the timer
                // Error occurred, resend all packets because we don't know what is going on
                resendMessage();
            }
        }else {
            System.out.println("unknown seq for receiveAckPacket");
        }
    }
}
