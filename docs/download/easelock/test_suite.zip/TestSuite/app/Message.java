package app;
import java.io.*; 

public class Message {
    public byte msgType;
    public short msgSize;
    public byte[] payload;

    public Message(byte msgType, short msgSize, byte[] payload) {
        this.msgType = msgType;
        this.msgSize = msgSize;
        this.payload = payload;
    }

    public static final byte MSG_TYPE_AUTH = 0x01;
    public static final byte MSG_TYPE_CHANGE_PASSWORD = 0x02;
    public static final byte MSG_TYPE_DOOR_COMMAND = 0x03;
    public static final byte MSG_TYPE_CHALLENGE_RESPONSE = 0x04;
    public static final byte MSG_TYPE_SYNC_TIMESTAMP = 0x05;
	public static final byte MSG_TYPE_ACK = 0x06;
	public static final byte MSG_TYPE_NOTIFY = 0x07;
	
    public static Message createAuthMessage(byte[] payload) {
        return new Message(MSG_TYPE_AUTH, (short) payload.length, payload);
    }

    public static Message createChangePasswordMessage(byte[] payload) {
        return new Message(MSG_TYPE_CHANGE_PASSWORD, (short) payload.length, payload);
    }

    public static Message createDoorCommandMessage(byte[] payload) {
        return new Message(MSG_TYPE_DOOR_COMMAND, (short) payload.length, payload);
    }

    public static Message createChallengeResponseMessage(byte[] challenge, byte[] passwordHash) {
        byte[] payload = new byte[challenge.length + passwordHash.length];
        System.arraycopy(challenge, 0, payload, 0, challenge.length);
        System.arraycopy(passwordHash, 0, payload, challenge.length, passwordHash.length);
        return new Message(MSG_TYPE_CHALLENGE_RESPONSE, (short) payload.length, payload);
    }

    public static Message createSyncTimestampMessage(long timestamp) {
        byte[] payload = new byte[4];
        payload[0] = (byte) (timestamp >> 24);
        payload[1] = (byte) (timestamp >> 16);
        payload[2] = (byte) (timestamp >> 8);
        payload[3] = (byte) timestamp;
        return new Message(MSG_TYPE_SYNC_TIMESTAMP, (short) payload.length, payload);
	}

	public static Message createAckMessage(short packetNumber, byte sequenceNumber, boolean status) {
		byte[] payload = new byte[4];
		payload[0] = (byte) (packetNumber >> 8);
		payload[1] = (byte) (packetNumber & 0xFF);
		payload[2] = sequenceNumber;
		payload[3] = (byte) (status ? 1 : 0);
		return new Message(MSG_TYPE_ACK, (short) payload.length, payload);
	}

	public static Message createNotifyMessage(short packetNumber, byte messageType, short result, byte[] desc) {
		byte[] payload = new byte[5 + desc.length];
		payload[0] = (byte) (packetNumber >> 8);
		payload[1] = (byte) (packetNumber & 0xFF);
		payload[2] = messageType;
		payload[3] = (byte) (result >> 8);
		payload[4] = (byte) (result & 0xFF);
		if (desc.length > 0) {
			System.arraycopy(desc, 0, payload, 5, desc.length);
		}
		return new Message(MSG_TYPE_NOTIFY, (short) payload.length, payload);
	}

	private int retransmissionCount = 0;

	public int getRetransmissionCount() {
		return retransmissionCount;
	}

	public void setRetransmissionCount(int retransmissionCount) {
		this.retransmissionCount = retransmissionCount;
	}

	public static short globalPktNO = 0;

	public static synchronized short generatePacketNumber() {
		return ++globalPktNO;
	}

	public static byte[][] fragmentPacket(Message msg, int mtuSize){
		if (mtuSize <= 8) {
            System.out.println("mtu size error");
            return null;
		}

		short pktID = Message.generatePacketNumber();
		int numPackets = (int) Math.ceil((double) msg.payload.length / (mtuSize - 8));
		byte[][] packets = new byte[numPackets][];

        System.out.println("message fragment results:");
		for (int i = 0; i < numPackets; i++) {
			int packetSize = Math.min(mtuSize - 8, msg.payload.length - i * (mtuSize - 8));
			byte[] packet = new byte[mtuSize];

			// set Packet Number
			packet[0] = (byte) (pktID >> 8); // pktNO
			packet[1] = (byte) (pktID & 0xFF); // pktNO

			// set Sequence Number
			packet[2] = (byte) ((i == 0) ? 0x80 : 0x00); // seqNO MSB
			packet[2] = (byte) (packet[2] | (numPackets - i)); // seqNO
			
			// set Message Type
			packet[5] = (byte) msg.msgType; // msgType

			// set Message Size
			short msize = (short)((i == 0) ? msg.payload.length : packetSize);
			packet[6] = (byte) ((msize >> 8) & 0xFF); // message size high byte
			packet[7] = (byte) (msize & 0xFF); // message size low byte

            // set current packet payload
            byte[] pdata = new byte[packetSize];
			System.arraycopy(msg.payload, i * (mtuSize - 8), packet, 8, packetSize);
			System.arraycopy(packet, 8, pdata, 0, packetSize);
            // set Checksum
			short chksum = crc16((i == 0)? msg.payload : pdata);
			packet[3] = (byte) (chksum >> 8); // checksum high byte
			packet[4] = (byte) (chksum & 0xFF); // checksum low byte
			packets[i] = packet;
            Message.log(packet);

		}
		return packets;
	}
    
    public static void log(byte[] packet) {
        if (packet == null || packet.length < 8) {
            System.out.println("Invalid packet");
            return;
        }

        short pktNO = (short) (((packet[0] & 0xFF) << 8) | (packet[1] & 0xFF));
        byte seqNO = packet[2];
        short checksum = (short) (((packet[3] & 0xFF) << 8) | (packet[4] & 0xFF));
        byte msgType = packet[5];
        short totalSize = (short) (((packet[6] & 0xFF) << 8) | (packet[7] & 0xFF));

        System.out.println("Packet Details:");
        System.out.println("  Packet Number: " + String.format("0x%04X", pktNO));
        System.out.println("  Sequence Number: " + String.format("0x%02X", seqNO));
        System.out.println("  Checksum: " + String.format("0x%04X", checksum));
        System.out.println("  Message Type: " + String.format("0x%02X", msgType));
        System.out.println("  Total Size: " + String.format("0x%04X", totalSize));
        StringBuilder sb = new StringBuilder();
        for (byte b : packet) {
            sb.append(String.format("%02x ", b));
        }
		System.out.println("Raw packet hex string:");
        System.out.println(sb.toString());
    }


	public static Message assemblePacket(byte[][] packets, int mtuSize) throws IOException{
		if (packets == null || packets.length == 0) {
			return null;
		}

		// Extract the packet number, sequence number, total message size and message type from the first packet
		short pktNO = (short) (((packets[0][0] & 0xFF) << 8) | (packets[0][1] & 0xFF));
		byte seqNO = packets[0][2];
		byte msgType = packets[0][5];
		short totalSize = (short) (((packets[0][6] & 0xFF) << 8) | (packets[0][7] & 0xFF));

		// Create a new byte array to store the reassembled payload
		byte[] payload = new byte[totalSize];

		// Reassemble the payload
		int offset = 0;
		for (byte[] packet : packets) {
		    int packetSize = (short) (((packet[6] & 0xFF) << 8) | (packet[7] & 0xFF));
			if (offset == 0) {
			    packetSize = Math.min(mtuSize - 8, packetSize);
			}
            System.out.println(String.format("assemblePacket: pktsize:0x%x,offset:0x%x,packetlen:0x%x",packetSize,offset,packet.length));
            log(packet);
			System.arraycopy(packet, 8, payload, offset, packetSize);
			offset += packetSize;
		}

		// Verify the checksum
		short chksum = crc16(payload);
		if (chksum!= ((short) (((packets[0][3] & 0xFF) << 8) | (packets[0][4] & 0xFF)))) {
			throw new IOException("Checksum mismatch");
		}

		// Create a new Message object with the reassembled payload
		Message msg = new Message(msgType, (short) totalSize, payload);
		return msg;
	}

    private static final int[] CRC16_TABLE = {
    0x0000, 0x1189, 0x2312, 0x329B, 0x4624, 0x57AD, 0x6536, 0x74BF,
    0x8C48, 0x9DC1, 0xAF5A, 0xBED3, 0xCA6C, 0xDBE5, 0xE97E, 0xF8F7,
    0x0919, 0x1890, 0x2A0B, 0x3B82, 0x4F3D, 0x5EB4, 0x6C2F, 0x7DA6,
    0x8551, 0x94D8, 0xA643, 0xB7CA, 0xC375, 0xD2FC, 0xE067, 0xF1EE,
    0x1232, 0x03BB, 0x3120, 0x20A9, 0x5416, 0x459F, 0x7704, 0x668D,
    0x9E7A, 0x8FF3, 0xBD68, 0xACE1, 0xD85E, 0xC9D7, 0xFB4C, 0xEAC5,
    0x1B2B, 0x0AA2, 0x3839, 0x29B0, 0x5D0F, 0x4C86, 0x7E1D, 0x6F94,
    0x9763, 0x86EA, 0xB471, 0xA5F8, 0xD147, 0xC0CE, 0xF255, 0xE3DC,
    0x2464, 0x35ED, 0x0776, 0x16FF, 0x6240, 0x73C9, 0x4152, 0x50DB,
    0xA82C, 0xB9A5, 0x8B3E, 0x9AB7, 0xEE08, 0xFF81, 0xCD1A, 0xDC93,
    0x2D7D, 0x3CF4, 0x0E6F, 0x1FE6, 0x6B59, 0x7AD0, 0x484B, 0x59C2,
    0xA135, 0xB0BC, 0x8227, 0x93AE, 0xE711, 0xF698, 0xC403, 0xD58A,
    0x3656, 0x27DF, 0x1544, 0x04CD, 0x7072, 0x61FB, 0x5360, 0x42E9,
    0xBA1E, 0xAB97, 0x990C, 0x8885, 0xFC3A, 0xEDB3, 0xDF28, 0xCEA1,
    0x3F4F, 0x2EC6, 0x1C5D, 0x0DD4, 0x796B, 0x68E2, 0x5A79, 0x4BF0,
    0xB307, 0xA28E, 0x9015, 0x819C, 0xF523, 0xE4AA, 0xD631, 0xC7B8,
    0x48C8, 0x5941, 0x6BDA, 0x7A53, 0x0EEC, 0x1F65, 0x2DFE, 0x3C77,
    0xC480, 0xD509, 0xE792, 0xF61B, 0x82A4, 0x932D, 0xA1B6, 0xB03F,
    0x41D1, 0x5058, 0x62C3, 0x734A, 0x07F5, 0x167C, 0x24E7, 0x356E,
    0xCD99, 0xDC10, 0xEE8B, 0xFF02, 0x8BBD, 0x9A34, 0xA8AF, 0xB926,
    0x5AFA, 0x4B73, 0x79E8, 0x6861, 0x1CDE, 0x0D57, 0x3FCC, 0x2E45,
    0xD6B2, 0xC73B, 0xF5A0, 0xE429, 0x9096, 0x811F, 0xB384, 0xA20D,
    0x53E3, 0x426A, 0x70F1, 0x6178, 0x15C7, 0x044E, 0x36D5, 0x275C,
    0xDFAB, 0xCE22, 0xFCB9, 0xED30, 0x998F, 0x8806, 0xBA9D, 0xAB14,
    0x6CAC, 0x7D25, 0x4FBE, 0x5E37, 0x2A88, 0x3B01, 0x099A, 0x1813,
    0xE0E4, 0xF16D, 0xC3F6, 0xD27F, 0xA6C0, 0xB749, 0x85D2, 0x945B,
    0x65B5, 0x743C, 0x46A7, 0x572E, 0x2391, 0x3218, 0x0083, 0x110A,
    0xE9FD, 0xF874, 0xCAEF, 0xDB66, 0xAFD9, 0xBE50, 0x8CCB, 0x9D42,
    0x7E9E, 0x6F17, 0x5D8C, 0x4C05, 0x38BA, 0x2933, 0x1BA8, 0x0A21,
    0xF2D6, 0xE35F, 0xD1C4, 0xC04D, 0xB4F2, 0xA57B, 0x97E0, 0x8669,
    0x7787, 0x660E, 0x5495, 0x451C, 0x31A3, 0x202A, 0x12B1, 0x0338,
    0xFBCF, 0xEA46, 0xD8DD, 0xC954, 0xBDEB, 0xAC62, 0x9EF9, 0x8F70
    };

    public static short crc16(byte[] data) {
        int crc = 0xFFFF;

        for (byte b : data) {
            crc = (crc >>> 8) ^ CRC16_TABLE[(crc ^ b) & 0xFF];
        }

        //return (short)(~crc & 0xFFFF);
        return (short) (crc & 0xFFFF);
    }



}
