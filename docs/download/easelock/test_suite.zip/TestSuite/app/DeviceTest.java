package app;

import java.io.*;
import java.net.*;

public class DeviceTest {
	private static final int PORT = 8080;

	public static void main(String[] args) {
		try {
			ServerSocket serverSocket = new ServerSocket(PORT, 50, InetAddress.getByName("127.0.0.1"));
			System.out.println("Server is listening on port " + PORT);

			// Accept a client connection
			try {
				Socket socket = serverSocket.accept();
				InputStream in = socket.getInputStream();
				OutputStream out = socket.getOutputStream();

				System.out.println("Client connected");

				// Handle incoming messages
				handleMessages(in, out);

			} catch (IOException e) {
				System.err.println("Client connection error: " + e.getMessage());
			}

		} catch (IOException e) {
			System.err.println("Server error: " + e.getMessage());
		}
	}
	public static void handleMessages(InputStream in, OutputStream out) throws IOException{
		System.out.println("handleMessages");
		MessageReceiver receiver = new MessageReceiver(in, out);
		Message authmsg = receiver.receiveMessage();
		String str = new String(authmsg.payload, "UTF-8");
		System.out.println(str);
        System.out.println("auth request OK");
        System.out.println("auth begin");
		MessageTransmitter sender = new MessageTransmitter(in, out);
        Message rspmsg = Message.createChallengeResponseMessage("1234".getBytes(),"".getBytes());
        sender.sendMessage(rspmsg);
        System.out.println("auth check");
		Message authrsp = receiver.receiveMessage();
        str = new String(authrsp.payload, "UTF-8");
		System.out.println(str);
        System.out.println("auth end");
        System.out.println("cmd begin");
        Message msg = receiver.receiveMessage();
        str = new String(msg.payload, "UTF-8");
		System.out.println(str);
        // TODO: Add more message tests in the following
        System.out.println("bye");



	}
}
