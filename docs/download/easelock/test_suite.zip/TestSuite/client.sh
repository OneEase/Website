javac app/Message.java
javac app/MessageTransmitter.java
javac app/MessageReceiver.java
javac app/MessageController.java
javac app/BluetoothCommunicationTest.java
java app.BluetoothCommunicationTest | tee client.log
