javac app/Message.java
javac app/MessageTransmitter.java
javac app/MessageReceiver.java
javac app/MessageController.java
javac app/DeviceTest.java
java app.DeviceTest | tee log
