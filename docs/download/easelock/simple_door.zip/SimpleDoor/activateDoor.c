#include <avr/io.h>
#include <util/delay.h>
#include "pinDefines.h"
#include "USART.h"

int main(void) {
  char serialCharacter;
  DDRB |= 0b0000001; 
  initUSART();

  while (1) {
    serialCharacter = receiveByte();
    transmitByte(serialCharacter);
	if (serialCharacter == 'y')
	{
		PORTB = 0b00000001;
	}
	if (serialCharacter == 'n')
	{
		PORTB = 0b00000000;
	} 
	_delay_ms(100);
  } 
  return 0;
}