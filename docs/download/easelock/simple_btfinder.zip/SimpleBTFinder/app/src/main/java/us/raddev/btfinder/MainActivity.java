package us.raddev.btfinder;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private ListView logView;
    private ArrayList<String> listViewItems = new ArrayList<String>();
    private ArrayAdapter<String> adapter;
    private ArrayList<String> logViewItems = new ArrayList<String>();
    private ArrayAdapter<String> logViewAdapter;

    private BluetoothAdapter btAdapter;
    private final static int REQUEST_ENABLE_BT = 1;
    private static BluetoothDevice btDevice;
    private ConnectThread ct;
    private Button yesButton;
    private Button noButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.mainListView);
        logView = (ListView) findViewById(R.id.logView);
        yesButton = (Button)findViewById(R.id.YesButton);
        noButton = (Button)findViewById(R.id.NoButton);

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listViewItems);
        listView.setAdapter(adapter);

        logViewAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, logViewItems);
        logView.setAdapter(logViewAdapter);

        for (int x = 0;x <=2;x++){
            adapter.add("test : " + String.valueOf(x));

        }
        adapter.notifyDataSetChanged();

        btAdapter = BluetoothAdapter.getDefaultAdapter();
        if (btAdapter != null) {
            if (!btAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
            GetPairedDevices();
            DiscoverAvailableDevices();
        }

        noButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ct.writeNo();
            }
        });

        yesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ct.writeYes();
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Log.d("MainActivity", "item clicked");

                Object o = listView.getItemAtPosition(position);
                String btDeviceInfo=(String)o;
                Log.d("MainActivity", "DeviceInfo : " + btDeviceInfo);
                logViewAdapter.add("DeviceInfo : " + btDeviceInfo);
                logViewAdapter.notifyDataSetChanged();
                if (btDevice != null) {
                    UUID uuid = btDevice.getUuids()[0].getUuid();
                    Log.d("MainActivity", uuid.toString());
                    logViewAdapter.add("UUID : " + uuid.toString());
                    logViewAdapter.notifyDataSetChanged();
                    if (ct == null) {
                        ct = new ConnectThread(btDevice, uuid, logViewAdapter);
                    }
                    ct.run(btAdapter);
                }
                else {
                    logViewAdapter.add("btDevice is null");
                    logViewAdapter.notifyDataSetChanged();
                }
//                Bundle bundle = new Bundle();
//                bundle.putString("noteFileName", fileName);
//                Intent i = new Intent(MainActivity.this, NoteActivity.class);
//                i.putExtras(bundle);
//                startActivity(i);
            }
        });
    }

    private void DiscoverAvailableDevices(){
        final BroadcastReceiver mReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                // When discovery finds a device
                if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                    // Get the BluetoothDevice object from the Intent
                    BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    // Add the name and address to an array adapter to show in a ListView
                    //btDevice = device;
                    adapter.add(device.getName() + "\n" + device.getAddress());
                    adapter.notifyDataSetChanged();
                }
            }
        };
// Register the BroadcastReceiver
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(mReceiver, filter); // Don't forget to unregister during onDestroy
    }

    private void GetPairedDevices() {
        Set<BluetoothDevice> pairedDevices = btAdapter.getBondedDevices();
        // If there are paired devices
        if (pairedDevices.size() > 0) {
            // Loop through paired devices
            for (BluetoothDevice device : pairedDevices) {
                btDevice = device;
                // Add the name and address to an array adapter to show in a ListView
                adapter.add(device.getName() + "\n" + device.getAddress());
            }
            adapter.notifyDataSetChanged();
        }
    }
}