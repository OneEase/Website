^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pi_io
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2019-05-02)
------------------
* First formal release of the package
