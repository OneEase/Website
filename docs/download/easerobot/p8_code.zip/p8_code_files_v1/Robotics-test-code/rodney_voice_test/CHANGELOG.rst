^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rodney_voice_test
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2018-09-13)
------------------
* First formal release of the package
