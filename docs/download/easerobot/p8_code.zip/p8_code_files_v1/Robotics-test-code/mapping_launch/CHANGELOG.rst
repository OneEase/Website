^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package mapping_launch
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2019-04-18)
------------------
* Removed bag files

0.1.0 (2019-03-19)
------------------
* First formal release of the package
