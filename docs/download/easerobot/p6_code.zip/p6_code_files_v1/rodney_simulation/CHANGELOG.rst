^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rodney_sim_control
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.5.0 (2019-04-10)
------------------
* Now using rodney static_broadcaster.py
* Now using willowgarage world

0.4.1 (2019-03-01)
------------------
* Fixed gravity error in Gazebo introduced with the PositionJointInterface 

0.4.0 (2019-02-19)
------------------
* Change in model from EffortJointInterface to PositionJointInterface
* Now launches rviz at the same time as Gazebo
* Added bash_scripts file to capture long winded ros commands

0.3.0 (2019-01-24)
------------------
* Added items to rodney.world

0.2.0 (2019-01-12)
------------------
* Change to head pan/tilt joint names

0.1.0 (2018-11-12)
------------------
* First formal release of the package
