^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package imu_calib
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2019-04-02)
------------------
* Changed topic names in apply_calib node
* Removed queue_size ros parameter in apply_calib node
* Added code to null accelerometer readings in apply_calib node

Original
------------------
* Forked from https://github.com/dpkoch/imu_calib
