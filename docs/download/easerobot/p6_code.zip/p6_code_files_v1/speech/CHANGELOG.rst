^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package speech
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2018-09-14)
------------------
* Add delay functionality between end of speech and sending /robot_face/talking_finished

0.1.0 (2018-07-12)
------------------
* First formal release of the package
