^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package servo_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2019-01-23)
------------------
* First formal release of the package
