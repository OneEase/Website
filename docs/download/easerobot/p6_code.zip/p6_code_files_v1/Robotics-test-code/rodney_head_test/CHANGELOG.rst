^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rodney_head_test
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.0 (2019-01-24)
------------------
* Feedback now contains current position which is reported
* Test now used radians

0.1.0 (2018-12-15)
------------------
* First formal release of the package
